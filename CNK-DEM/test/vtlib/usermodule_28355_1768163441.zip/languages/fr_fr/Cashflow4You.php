<?php
/* * *******************************************************************************
 * The content of this file is subject to the Cashflow4You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

$languageStrings = Array(
    'Cashflow4You' => 'Cashflow',
    'SINGLE_Cashflow4You' => 'Cashflow',
    'Cashflow4You ID' => 'Identifiant Cashflow',
    
    'LBL_MODULE_NAME' => 'Cashflow',
    'LBL_ADD_RECORD' => 'Ajouter un paiement',
    'LBL_RECORDS_LIST' => 'Cashflow',
    'LBL_CASHFLOW_INFORMATION' => 'Renseignements sur le Paiement',
    'LBL_CUSTOM_INFORMATION' => 'Informations personnalisées',
    'LBL_MODULEBLOCK_INFORMATION' => 'Champ Information',
    'LBL_TAX_INFORMATION' => 'Informations comptables',
    
    'ModuleFieldLabel' => 'Champ Texte',
    
    'Cashflow4You Name' => 'Nom du paiement',
    'Cashflow4You No' => 'Paiement n°',
    'Payment Date' => 'Date du Paiement',
    'Payment Method' => 'Moyen de paiement',
    'Paid Amount' => 'Quantité',
    'Relation' => 'Référence',
    'Transaction ID' => 'Identifiant de la transaction',
    'Due Date' => 'Date d\'échéance',
    'Currency' => 'Monnaie',
    'Payment Type' => 'Type de Paiement',
    'Payment Category' => 'Catégorie du Paiement',
    'Related To' => 'Relié à',
    'Created_Time' => 'Temps créé',
    'Modified Time' => 'Temps modifié',
    'Payment Mode' => 'Mode de paiement',
    'Payment Subcategory' => 'Sous-catégorie du Paiement',
    'Payment Status' => 'Etat du Paiement',
    'Description' => 'Description',
    'Accounting Date' => 'Date Comptable',
    'VAT' => 'Total de la TVA',
    'Price without VAT' => 'Prix HT',
    'Tax Component' => 'Composants de la Taxe',
    'Assigned To' => 'Affecté à',
    'Associated No' => 'Référence N°',
    'Remaining Amount' => 'Quantité restante',
    'Relations' => 'Relations',    
    
    'Create_Payment' => 'Créer un règlement',
    'LBL_CASHFLOW_SAME_ORGA' => 'Les organismes doivent être les mêmes.',
    
    'relation_am'=>'Total des relations',
    'invoice_am' => 'Total des factures',
    'po_am' => 'Total des commandes passées',
    'paid' => 'Montant versé',
    'Paid' => 'Payé',
    'to_pay' => 'Somme à payer',
    'LOAD_PAYMENTS' => 'Lancer les paiements',
    'p_pending'=>'Imminent',
    'Pending' => 'Imminent',
    'Waiting' => 'En attente',
    'Received' => 'Reçu',
    'Created' => 'Créé',
    'Add_Payment' => 'Ajouter un Paiement',
    // ITS4YOU-CR SlOl 10/31/2011 9:32:06 
    'paytype'=>'Type de paiement',
    'Incoming'=>'Entrant',
    'Outgoing'=>'Sortant',
    'Multiple_Payment' => 'Paiement Multiple',
    'PaymentDetails' => 'Détails du Paiement',

    'Relation_Nr' => 'Relation N°',
    'RelatedInformation' => 'Renseignements sur la Référence',
    'Cost' => 'Frais',
    'Total_Amount' => 'Montant total',
    'Other' => 'Autre',
    'Income_for_services' => 'Recettes des services',
    'Income_for_products' => 'Recettes des produits',
    'Office_cost' => 'Coût des bureaux',
    'Telephone' => 'Téléphone',
    'Salaries' => 'Salariés',
    'Wages' => 'Salaires',
    'Rent' => 'Rentabilité',
    'Fuel' => 'Carburant',
    

    'INFO_RELATED_STATUS_CHANGE' => 'Le statut des factures liées sera changé en '.getTranslatedString('Payé','Facture'),
    'negative_check_alert' => 'Le montant versé devrait être un nombre négatif du fait des paiements sortants',
    'not_negative_check_alert' => 'Le montant versé devrait être supérieur à zéro du fait des paiements entrants',

    'cf4youcash' => 'Mode de Paiement',
    'Cashflow' => 'Espèces',
    'Cash' => 'Espèces',
    'Bank account' => 'Compte Bancaire',
    'accountingdate' => 'Date Comptable',
    
    'LBL_CASHFLOW_ADD_INVOICE' => 'Ajouter des factures',
    //copyright
    "COPYRIGHT" => ":: IT-Solutions4You",
    
    //Select Wizard ERR
    'LBL_CASHFLOW_SAME_ORGA' => 'Les organismes doivent être les mêmes',

    //quick casflow create
    'LBL_CASHFLOW_SUMMARY' => 'Résumé',
    'LBL_CASHFLOW_BALANCE' => 'Solde',
    'LBL_CASHFLOW_PAYMENT' => 'Paiement',
    'LBL_CASHFLOW_ALREADY_PAYD' => 'Déjà payé',
    'LBL_CASHFLOW_OUTSTANDING_BALANCE' => 'Solde exigible',
    'LBL_CASHFLOW_OPEN_AMOUNT' => 'Montant restant',
    'LBL_PAY_OFF' => 'Pay Off',

    //error
    'LBL_CASHFLOW_IS_NAN' => 'est non valide',
    'LBL_CASHFLOW_HIGH' => 'Haut',
    'LBL_CASHFLOW_CHANGE_PAYMENT_QUEST' => 'Etes-vous sûr de changer le paiement ?',
    'LBL_CASHFLOW_BALLANCE_OUT_RANGE' => 'Le paiement du solde doit être de 0',

    'LBL_CASHFLOW_IS_SAVED' => 'est Sauvegardé',
    'LBL_CASHFLOW_SAVE_ERROR' => 'Erreur lors de l\'enregistrement de Cashflow',

  //installation
    "LBL_INSTALL" => "installation",
    "LBL_VALIDATION" => "Validation",
    "LBL_FINISH" => "Finir",
    "LBL_WELCOME" => "Bienvenue sur l\''assistant d\'installation de Cashflow",
    "LBL_WELCOME_DESC" => "Cela installera Cashflow dans votre vtiger CRM.",
    "LBL_WELCOME_FINISH" => "Il est fortement recommandé de terminer l\'installation sans interruption.",
    "LBL_INSERT_KEY" => "Veuillez insérer la clé de licence reçue dans l\'email de confirmation de l\'achat.",
    "LBL_LICENSE_KEY" => "Clé de licence",
    "LBL_ACTIVATE_KEY" => "Activer la licence",
    "LBL_VALIDATE" => "Valider",
    "LBL_ONLINE_ASSURE" => "Veuillez vous assurer que votre serveur soit connecté à internet afin de mener à bien la validation.",
    "LBL_ORDER_NOW" => "Commander maintenant",
    "LBL_INVALID_KEY" => "Clé de licence non valide ! Veuillez contacter le vendeur de Cashflow.",
    "LBL_INSTALL_SUCCESS" => "Cashflow a été installé correctement.",
    
    "LBL_LICENSE" => "Paramètres de la licence",
    "LBL_LICENSE_DESC" => "Gérez tous les paramètres liés à votre licence",
    "LBL_REACTIVATE" => "Réactiver la licence",
    "REACTIVATE_SUCCESS" => "Vous avez correctement réactivé Cashflow.",
    "LBL_DEACTIVATE" => "Désactiver la licence",
    "LBL_DEACTIVATE_TITLE" => "Désactiver la licence",
    'LICENSE_SETTINGS' => 'Licence',
    'LICENSE_SETTINGS_INFO' => 'Gérez votre clé de licence',
    
    "LBL_INACTIVE" => "Cashflow est inactif. Veuillez insérer la clé de licence.",
    "LBL_DEACTIVATE_SUCCESS" => "La clé de licence a été correctement désactivée.",
    "LBL_REACTIVATE_DESC" => "En cas de problème avec la clé de licence.",
    
    "ALERT_DOC_TITLE" => "Le titre du document ne peut être vide.",
    
    // integration
    "LBL_INTEGRATION" => "Intégration",
    "LBL_INTEGRATION_DESC" => "Intégration de Cashflow dans d\'autres modules",
    "INTEGRATION" => "Intégration",
     "LBL_AVAILABLE_MODULES" => "Modules disponibles",
    
    //uninstal
    "LBL_UNINSTALL" => "Désinstaller",
    "LBL_UNINSTALL_DESC" => "Désinstaller complètement Cashflow de votre vTiger.",
    
    "ITS4YouPreInvoice" => "Facture Proforma",
    "CreditNotes4You" => "Crédits",

    // Traductions manquantes
    "Payments" => "Règlements",
    "Grand Total" => "Montant total",
    "Total amount" => "Montant réglé",
    "Balance" => "Solde",
    "LBL_YES" => "Oui",
    
    'LBL_COMPANY_LICENSE_INFO' => 'Your Company Information',
    'LBL_URL' => 'Your vtiger url',
    'LBL_CHANGE_COMPANY_INFORMATION' => 'Change Company Information',
    'LBL_LICENSE_SETTINGS_INFO' => 'Manage your License Key',
    
    "LBL_LICENSE_DUE_DATE" => "Due Date",
    "LBL_CLASS_VTIGER_NET_CLIENT_DOES_NOT_EXIST" => "Class vtiger_net_client does not exist",
);

$jsLanguageStrings = array(
    "LBL_DEACTIVATE_QUESTION" => "Voulez-vous vraiment désactiver votre clé de licence ?",
    "LBL_UNINSTALL_CONFIRM" => "Etes-vous sûr de vouloir complètement désinstaller Cashflow de votre vTiger et de désactiver votre licence Cashflow ?",
);
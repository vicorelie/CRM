/* * *******************************************************************************
 * The content of this file is subject to the Cashflow4You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */
/** @var Cashflow4You_Actions_Js */

jQuery.Class("Cashflow4You_Actions_Js", {
    instance: false,
    getInstance: function () {
        if (!this.instance) {
            this.instance = new Cashflow4You_Actions_Js();
        }

        return this.instance;
    },
    getListViewPopup: function (e, source_module) {
        this.CreatePayment(e, source_module);
    },

    showPayments: function () {
        const recordId = app.getRecordId(),
            sourceModule = app.getModuleName(),
            postData = {
                'module': 'Cashflow4You',
                'view': 'ListPayments',
                'source_module': sourceModule,
                'record': recordId
            };

        app.helper.showProgress();
        app.request.post({data: postData}).then(function (error, response) {
            app.helper.hideProgress();
            if (!error) {
                const data = {}
                data['cb'] = function (modalContainer) {
                    modalContainer.find('#js-addpayment-button').on('click', function () {
                        window.location.href = 'index.php?module=Cashflow4You&view=Edit&relationid=' + recordId + '&sourceModule=' + sourceModule + '&relationOperation=1&sourceRecord=' + recordId;
                    });
                };
                app.helper.showModal(response, data);
            }
        });
    },
    CreatePayment: function () {
        let thisInstance = this,
            listInstance = app.controller(),
            validationResult = listInstance.checkListRecordSelected(),
            selectedIds = listInstance.readSelectedIds(true),
            excludedIds = listInstance.readExcludedIds(true),
            cvId = listInstance.getCurrentCvId(),
            postData = {
                module: 'Cashflow4You',
                view: 'CreatePaymentActionAjax',
                mode: 'showCreatePaymentForm',
                viewname: cvId,
                selected_ids: selectedIds,
                excluded_ids: excludedIds,
            };

        app.request.post({'data': postData}).then(function (error, response) {
            if (!error) {
                let resp = response.split('|||###|||');

                if (2 === resp.length) {
                    app.helper.showErrorNotification({"message": resp[1]});
                } else {
                    let callback = function (container) {
                        $('[name="paymentamount"]', container).on('change', function () {
                            thisInstance.checkPaymentAmount(thisInstance);
                        });

                        $('#js-save-cashflow', container).on('click', function () {
                            let form = container.find('form');

                            if (form.valid()) {
                                if (thisInstance.CheckCreatePayment(form)) {
                                    let formData = form.serializeFormData();

                                    app.request.post({'data': formData}).then(function (error, res) {
                                        app.helper.hideProgress();

                                        if (!error) {
                                            app.helper.hideModal();
                                            app.helper.showSuccessNotification({
                                                'message': res.message
                                            });
                                        }

                                        listInstance.loadListViewRecords().then(function () {
                                            const checkBox = $('.listViewEntriesMainCheckBox');

                                            checkBox.attr('checked', 'checked');
                                            checkBox.trigger('click');
                                        });
                                    });
                                }
                            }
                        });
                    };
                    let data = {};
                    data['cb'] = callback;
                    app.helper.hideProgress();
                    app.helper.showModal(response, data);
                }
            }
        });
    },
    postCEdit: function (massEditContainer) {
        let thisInstance = this;

        massEditContainer.find('form').on('submit', function (e) {
            e.preventDefault();
            let form = $(e.currentTarget),
                invalidFields = form.data('jqv').InvalidFields;

            if (0 === invalidFields.length) {
                form.find('[name="saveButton"]').attr('disabled', "disabled");
            }

            invalidFields = form.data('jqv').InvalidFields;

            if (0 < invalidFields.length) {
                return;
            }

            thisInstance.cActionSave(form, true).then(
                function (data) {
                    /** @var Vtiger_List_Js */
                    let listViewInstance = Vtiger_List_Js.getInstance();
                    listViewInstance.getListViewRecords();
                    Vtiger_List_Js.clearList();
                },
                function (error, err) {
                }
            )
        });
    },
    cActionSave: function (form, isMassEdit) {
        if ('undefined' === typeof isMassEdit) {
            isMassEdit = false;
        }

        let aDeferred = jQuery.Deferred(),
            massActionUrl = form.serializeFormData();

        if (isMassEdit) {
            //on submit form trigger the massEditPreSave event
            let massEditPreSaveEvent = jQuery.Event(Vtiger_List_Js.massEditPreSave);
            form.trigger(massEditPreSaveEvent);

            if (massEditPreSaveEvent.isDefaultPrevented()) {
                form.find('[name="saveButton"]').removeAttr('disabled');
                aDeferred.reject();

                return aDeferred.promise();
            }
        }

        AppConnector.request(massActionUrl).then(function (data) {
            let success = data['result']['success'],
                message = app.vtranslate(data['result']['message']),
                params = {
                    text: message
                };

            if (success) {
                params['type'] = 'info';
            }

            Vtiger_Helper_Js.showPnotify(params);
            app.hideModalWindow();
            aDeferred.resolve(data);
        }, function (error, err) {
            app.hideModalWindow();
            aDeferred.reject(error, err);
        });

        return aDeferred.promise();
    },
    getFormatedSum: function (element) {
        let value = element.val(),
            groupSeparator = app.getGroupingSeparator(),
            decimalSeparator = app.getDecimalSeparator(),
            strippedValue = value.replace(groupSeparator, ''),
            spacePattern = /\s/;

        if (spacePattern.test(decimalSeparator)) {
            strippedValue = strippedValue.replace(/ /g, '.');
        }

        strippedValue = strippedValue.replace(decimalSeparator, '.');
        strippedValue = strippedValue.replace(/[^0-9.]/g, '');

        if (isNaN(strippedValue)) {
            alert($('#paid_is_nan').html());
        }

        strippedValue = strippedValue * 1;

        return strippedValue;
    },
    getPaymentAmount: function () {
        let element = $('[name="paymentamount"]');

        return this.getFormatedSum(element);
    },
    setPaymentAmount: function (paymentAmount) {
        let currency_symbol = $('#currency_symbol').val(),
            paymentAmount_formated = app.convertCurrencyToUserFormat(paymentAmount, currency_symbol);

        $('[name="paymentamount"]').val(paymentAmount_formated);
    },
    checkPaymentAmount: function (thisInstance) {
        let self = this,
            idstring = $('#idstring').val(),
            idlist = idstring.split(';'),
            sum_open_amount = eval($('#summ_openamount_hidden').val()),
            currency_symbol = $('#currency_symbol').val(),
            paid_amount = thisInstance.getPaymentAmount();

        if (isNaN(sum_open_amount)) {
            alert($('#sumary_is_nan').html());
        }

        for (let i = 0; i < idlist.length; i++) {
            $('#payment_chck_' + idlist[i]).attr('checked', false);
        }

        let open_amount = paid_amount,
            tmp_open_amount = paid_amount,
            tmp_sum_open_amount = sum_open_amount,
            sum_payment = 0,
            sum_outstandingbalance = 0,
            sum_balance_payment;

        for (let i = 0; i < idlist.length; i++) {
            let partial_open_amount = $('#openamount_' + idlist[i]).val() * 1,
                j = i + 1;

            if (isNaN(partial_open_amount)) {
                alert($('#open_amount').html() + " " + j + " " + $('#is_nan').html());
            } else {
                let payment;

                if (0 >= tmp_open_amount) {
                    payment = 0;
                } else if (tmp_open_amount < partial_open_amount) {
                    payment = tmp_open_amount;
                    tmp_open_amount = 0;
                } else {
                    payment = partial_open_amount;
                    tmp_open_amount -= partial_open_amount;
                }

                payment = Math.round(payment * 100) / 100;
                sum_payment += payment;
                $('#payment_' + idlist[i]).val(app.convertCurrencyToUserFormat(payment, ''));
                $('#previous_payment_' + idlist[i]).val(payment.toFixed(2));

                let outstandingbalance = payment - partial_open_amount;
                outstandingbalance = Math.round((outstandingbalance) * 100) / 100;

                let color = self.getColor(outstandingbalance.toFixed(2)),
                    outstandingbalance_formated = app.convertCurrencyToUserFormat(outstandingbalance, currency_symbol),
                    outstandingBalance = $('#outstandingbalance_' + idlist[i]);

                outstandingBalance.html(outstandingbalance_formated);
                outstandingBalance.css({color: color});

                tmp_sum_open_amount -= payment
                sum_outstandingbalance += outstandingbalance;
            }
        }

        sum_payment = Math.round(sum_payment * 100) / 100;
        tmp_sum_open_amount = Math.round(tmp_sum_open_amount * 100) / 100;
        sum_balance_payment = Math.round((paid_amount - sum_payment) * 100) / 100;
        sum_outstandingbalance = Math.round((sum_outstandingbalance) * 100) / 100;


        $('#summ_payment').html(app.convertCurrencyToUserFormat(sum_payment, currency_symbol));
        $('#summ_payment_hidden').html(sum_payment.toFixed(2));

        let color = self.getColor(sum_outstandingbalance.toFixed(2)),
            summ_outstandingbalance_formated = app.convertCurrencyToUserFormat(sum_outstandingbalance, currency_symbol),
            outStandingBalance = $('#summ_outstandingbalance'),
            outStandingBalanceHidden = $('#summ_outstandingbalance_hidden');

        outStandingBalance.html(summ_outstandingbalance_formated);
        outStandingBalance.css({color: color});

        outStandingBalanceHidden.html(summ_outstandingbalance_formated);
        outStandingBalanceHidden.css({color: color});

        color = self.getColor(tmp_sum_open_amount.toFixed(2));

        let balanceOpenAmount = $('#balance_openamount');

        balanceOpenAmount.html(app.convertCurrencyToUserFormat(tmp_sum_open_amount, currency_symbol));
        balanceOpenAmount.css({
            color: color,
            'font-weight': 'bold',
        });

        color = self.getColor(sum_balance_payment.toFixed(2));

        let balancePayment = $('#balance_payment'),
            balancePaymentHidden = $('#balance_payment_hidden'),
            paymentAmountHidden = $('#paymentamount_hidden');

        balancePayment.html(app.convertCurrencyToUserFormat(sum_balance_payment, currency_symbol));
        balancePayment.css({
            color: color,
            'font-weight': 'bold',
        });

        balancePaymentHidden.val(sum_balance_payment.toFixed(2));

        paymentAmountHidden.val(paid_amount.toFixed(2));

        let vatAmount

        if (0 != tmp_sum_open_amount.toFixed(2)) {
            vatAmount = 0;
        } else {
            vatAmount = eval($('#vat_amount_hidden').val());
        }

        $('#vat_amount').val(vatAmount);
    },
    getColor: function (number) {
        if (0.00 != number) {
            return '#FF0000';
        }

        return '#009900';
    },
    checkPayment: function (invid) {
        let self = this,
            idstring = $('#idstring').val(),
            idlist = idstring.split(';'),
            paid_amount = eval($('#paymentamount_hidden').val()),
            sum_open_amount = eval($('#summ_openamount_hidden').val()),
            currency_symbol = $('#currency_symbol').val(),
            color;

        if (isNaN(paid_amount)) {
            alert($('#paid_is_nan').html());
        }
        if (isNaN(sum_open_amount)) {
            alert($('#sumary_is_nan').html());
        }

        let open_amount = paid_amount,
            tmp_open_amount = paid_amount,
            tmp_sum_open_amount = sum_open_amount,
            sum_payment = 0,
            sum_outstandingbalance = 0,
            outstandingbalance_tmp = 0,
            sum_balance_payment;

        for (let i = 0; i < idlist.length; i++) {
            let j = i + 1,
                partial_amount = this.getFormatedSum($('#payment_' + idlist[i])),
                previous_partial_amount = $('#previous_payment_' + idlist[i]).val() * 1,
                partial_open_amount = $('#openamount_' + idlist[i]).val() * 1,
                payment,
                outstandingbalance;

            if (isNaN(partial_open_amount)) {
                alert($('#open_amount').html() + " " + j + " " + $('#is_nan').html());
            } else if (isNaN(partial_amount)) {
                alert($('#payment').html() + " " + j + " " + $('#is_nan').html());
            } else if (partial_amount > partial_open_amount) {
                payment = partial_amount;
                tmp_open_amount -= payment;
                payment = Math.round(payment * 100) / 100;
                sum_payment += payment;
                outstandingbalance = payment - partial_open_amount;
                outstandingbalance = Math.round((outstandingbalance) * 100) / 100;
                sum_outstandingbalance += outstandingbalance;

                if (invid == idlist[i]) {
                    if (confirm($('#high_payment').html())) {
                        let outstandingBalanceElement = $('#outstandingbalance_' + idlist[i]);
                        $('#previous_payment_' + idlist[i]).val(payment.toFixed(2));
                        color = self.getColor(outstandingbalance.toFixed(2));

                        outstandingBalanceElement.html(app.convertCurrencyToUserFormat(outstandingbalance, currency_symbol));
                        outstandingBalanceElement.css({color: color});
                    } else {
                        payment = previous_partial_amount;
                        tmp_open_amount = Math.round(tmp_partial_open_amount * 100) / 100;
                        sum_payment -= partial_amount;
                        sum_payment += payment;
                        sum_outstandingbalance -= outstandingbalance;
                        sum_outstandingbalance += payment;
                    }

                    $('#payment_' + idlist[i]).val(app.convertCurrencyToUserFormat(payment, ''));
                }

                outstandingbalance_tmp += Math.abs(outstandingbalance.toFixed(2));
                tmp_sum_open_amount -= payment
            } else {
                payment = partial_amount;
                tmp_open_amount -= payment;
                payment = Math.round(payment * 100) / 100;
                sum_payment += payment;
                outstandingbalance = payment - partial_open_amount;
                outstandingbalance = Math.round((outstandingbalance) * 100) / 100;
                sum_outstandingbalance += outstandingbalance;

                if (invid == idlist[i]) {
                    let outstandingBalanceElement = $('#outstandingbalance_' + idlist[i]);
                    $('#payment_' + idlist[i]).val(app.convertCurrencyToUserFormat(payment, ''));

                    color = self.getColor(outstandingbalance.toFixed(2));

                    outstandingBalanceElement.html(app.convertCurrencyToUserFormat(outstandingbalance, currency_symbol));
                    outstandingBalanceElement.css({color: color});
                }
                tmp_sum_open_amount -= payment;
                outstandingbalance_tmp += Math.abs(outstandingbalance.toFixed(2));
            }
        }

        tmp_sum_open_amount = Math.round(tmp_sum_open_amount * 100) / 100;
        sum_balance_payment = Math.round((paid_amount - sum_payment) * 100) / 100;
        sum_outstandingbalance = Math.round((sum_outstandingbalance) * 100) / 100;

        $('#summ_payment').html(app.convertCurrencyToUserFormat(sum_payment, currency_symbol));
        $('#summ_payment_hidden').html(sum_payment.toFixed(2));

        color = self.getColor(sum_outstandingbalance.toFixed(2));

        let summOutstandingBalanceElement = $('#summ_outstandingbalance'),
            summOutstandingBalanceHiddenElement = $('#summ_outstandingbalance_hidden');

        summOutstandingBalanceElement.html(app.convertCurrencyToUserFormat(sum_outstandingbalance, currency_symbol));
        summOutstandingBalanceElement.css({color: color});

        summOutstandingBalanceHiddenElement.html(app.convertCurrencyToUserFormat(sum_outstandingbalance, currency_symbol));
        summOutstandingBalanceHiddenElement.css({color: color});

        color = self.getColor(tmp_sum_open_amount.toFixed(2));

        let balanceOpenAmountElement = $('#balance_openamount'),
            balancePaymentElement = $('#balance_payment'),
            balancePaymentHiddenElement = $('#balance_payment_hidden');

        balanceOpenAmountElement.html(app.convertCurrencyToUserFormat(tmp_sum_open_amount, currency_symbol));
        balanceOpenAmountElement.css({
            color: color,
            'font-weight': 'bold',
        });

        color = self.getColor(sum_balance_payment.toFixed(2));

        balancePaymentElement.html(app.convertCurrencyToUserFormat(sum_balance_payment, currency_symbol));
        balancePaymentElement.css({
            color: color,
            'font-weight': 'bold',
        });
        balancePaymentHiddenElement.val(sum_balance_payment.toFixed(2));

        let vat_amount_val = eval($('#vat_amount_hidden').val());

        if (0 != outstandingbalance_tmp.toFixed(2)) {
            vat_amount_val = 0;
        }

        $('#vat_amount').val(vat_amount_val);
    },

    SetPayment: function (invid) {
        let self = this,
            idstring = $('#idstring').val(),
            idlist = idstring.split(';'),
            paid_amount = eval($('#paymentamount_hidden').val() * 1),
            sum_open_amount = eval($('#summ_openamount_hidden').val() * 1),
            currency_symbol = $('#currency_symbol').val(),
            paid_value = paid_amount;

        if (isNaN(paid_amount)) {
            alert($('#paid_is_nan').html());
        }
        if (isNaN(sum_open_amount)) {
            alert($('#sumary_is_nan').html());
        }

        let paymentCheckbox = $('#payment_chck_' + invid),
            paymentElement = $('#payment_' + invid);

        if (paymentCheckbox.is(":checked")) {
            paymentCheckbox.attr('readonly', true);

            for (let i = 0; i < idlist.length; i++) {
                if ($('#payment_chck_' + idlist[i]).is(":checked")) {
                    if (idlist[i] != invid) {
                        paid_value -= this.getFormatedSum($('#payment_' + idlist[i]));
                    }
                } else {
                    let value = 0.00;
                    $('#payment_' + idlist[i]).val(app.convertCurrencyToUserFormat(value, ''));
                    let outstandingbalance = value;
                    outstandingbalance -= $('#openamount_' + idlist[i]).val() * 1;

                    let color = self.getColor(outstandingbalance.toFixed(2)),
                        outstandingBalanceElement = $('#outstandingbalance_' + idlist[i]);

                    outstandingBalanceElement.html(app.convertCurrencyToUserFormat(outstandingbalance, currency_symbol));
                    outstandingBalanceElement.css({color: color});
                }
            }
            let open_amount = $('#openamount_' + invid).val() * 1,
                payment = 0.00,
                outstandingbalance = 0.00;

            if (paid_value >= open_amount) {
                payment = open_amount;
            } else if (paid_value > 0) {
                payment = paid_value;
                outstandingbalance = payment - open_amount;
            } else {
                payment = 0.00;
                outstandingbalance = payment - open_amount;
            }

            paymentElement.val(app.convertCurrencyToUserFormat(payment, ''));

            let color = self.getColor(outstandingbalance.toFixed(2)),
                outstandingBalanceElement = $('#outstandingbalance_' + invid);

            outstandingBalanceElement.html(app.convertCurrencyToUserFormat(outstandingbalance, currency_symbol));
            outstandingBalanceElement.css({color: color});

        } else {
            paymentCheckbox.attr('checked', false);
            paymentElement.attr('readonly', false);
        }
    },

    RecalculatePayment: function (invid) {
        let idstring = $('#idstring').val(),
            idlist = idstring.split(';'),
            paid_amount = eval($('#paymentamount_hidden').val()) * 1,
            balance_payment_hidden = eval($('#balance_payment_hidden').val()),
            openamount = $('#openamount_' + invid).val() * 1,
            paymentElement = $('#payment_' + invid),
            payment = this.getFormatedSum(paymentElement);

        for (let i = 0; i < idlist.length; i++) {
            if (idlist[i] != invid) {
                paid_amount -= this.getFormatedSum($('#payment_' + idlist[i]));
            }
        }

        if (paid_amount > 0) {
            if (paid_amount >= openamount) {
                payment = openamount;
            } else {
                payment = paid_amount;
            }
        } else {
            payment = 0.00;
        }

        paymentElement.val(app.convertCurrencyToUserFormat(payment, ''));

        Cashflow4You_Actions_Js.checkPayment(invid);
    },
    CheckCreatePayment: function () {
        let  balance_payment = eval($('#balance_payment_hidden').val());

        if (balance_payment != 0.00) {
            alert($('#zero_balance').html());
            return false;
        }

        return true;
    }
}, {
    registerEvents: function () {
        this.registerReceiverReadOnly();
        this.registerHideUnlink();
        this.registerPaymentsWidget();
    },
    registerPaymentsWidget: function () {
        const self = this;

        if (self.isSummaryView() && self.isPaymentAllowed()) {
            self.showPaymentsWidget();
        }

        app.event.on('post.relatedListLoad.click', function (event, searchRow) {
            if (self.isSummaryView() && self.isPaymentAllowed()) {
                self.showPaymentsWidget();
            }
        });
    },
    isSummaryView: function () {
        return 'LBL_RECORD_SUMMARY' === this.getLinkKey();
    },
    getLinkKey: function () {
        return $('div.related-tabs').find('li.active').data('link-key');
    },
    showPaymentsWidget: function () {
        const postData = {
            module: 'Cashflow4You',
            view: 'ListPayments',
            source_module: app.getModuleName(),
            record: app.getRecordId(),
            mode: 'Widget',
        };

        app.request.post({'data': postData}).then(function (error, data) {
            if (!error) {
                $('#detailView .middle-block').append(data);
            }
        });
    },
    isPaymentAllowed: function () {
        return $('li[id*="_detailView_moreAction_Payments"]').length > 0;
    },
    registerHideUnlink: function () {
        const self = this;

        self.hideUnlink();

        app.event.on('post.relatedListLoad.click', function (event, container) {
            self.hideUnlink();
        });
    },
    hideUnlink: function () {
        const relContainer = $('.relatedContainer'),
            relModule = relContainer.find('.relatedModuleName').val();

        if (relContainer.length && 'Cashflow4You' === relModule) {
            relContainer.find('.relationDelete').addClass('hide');
        }
    },
    registerReceiverReadOnly: function () {
        const received = $('.fieldBlockContainer input#received');

        if (received.length) {
            received.attr('readonly', 'readonly');
        }
    },
});

$(function () {
    Cashflow4You_Actions_Js.getInstance().registerEvents();
});
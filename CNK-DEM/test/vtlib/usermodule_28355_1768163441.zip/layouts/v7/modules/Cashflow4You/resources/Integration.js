/* * *******************************************************************************
 * The content of this file is subject to the Descriptions4You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

/** @var Cashflow4You_Integration_Js */
Vtiger_Index_Js('Cashflow4You_Integration_Js', {}, {
    registerEvents: function () {
        this._super();
        this.registerStatusValues();
    },
    registerStatusValues: function () {
        const self = this,
            statusFields = jQuery('select.status_field');

        statusFields.each(function () {
            self.updateStatusPicklists(jQuery(this), true);
        });

        statusFields.on('change', function () {
            self.updateStatusPicklists(jQuery(this));
        });
    },
    getSelectedOption: function(select) {
        let option = select.find('option[value="' + select.select2('val') + '"]');

        if(!option.length) {
            option = select.find('option');
        }

        return option;
    },
    generateOptions: function(picklistValues) {
        let options = '<option value="">' + app.vtranslate('JS_NONE') + '</option>';

        if (picklistValues) {
            jQuery.each(picklistValues, function (name, label) {
                options += '<option value="' + name + '">' + label + '</option>';
            });
        }

        return options;
    },
    updateStatusPicklists: function (statusField, updateSelected = false) {
        let self = this,
            tr = statusField.parents('tr'),
            statusValue = tr.find('select.status_value'),
            statusValueBack = tr.find('select.status_value_back'),
            picklistValues = self.getSelectedOption(statusField).data('picklist'),
            options = self.generateOptions(picklistValues);

        statusValue.html(options);
        statusValueBack.html(options);

        if(updateSelected) {
            statusValue.select2('val', statusField.data('status_value'));
            statusValueBack.select2('val', statusField.data('status_value_back'));
        }
    }
});
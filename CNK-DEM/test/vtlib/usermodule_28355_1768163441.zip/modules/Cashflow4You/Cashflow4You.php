<?php
/* * *******************************************************************************
 * The content of this file is subject to the Cashflow4You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

class Cashflow4You extends CRMEntity
{
    public $db, $log; // Used in class functions of CRMEntity

    public $table_name = 'its4you_cashflow4you';
    public $table_index = 'cashflow4youid';
    public $column_fields = array();

    public $moduleName = 'Cashflow4You';
    public $parentName = 'Sales';
    public $module;

    /**
     * Mandatory table for supporting custom fields.
     */
    public $customFieldTable = array('its4you_cashflow4youcf', 'cashflow4youid');

    /**
     * Mandatory for Saving, Include tables related to this module.
     */
    public $tab_name = array('vtiger_crmentity', 'its4you_cashflow4you', 'its4you_cashflow4youcf');

    /**
     * Mandatory for Saving, Include tablename and tablekey columnname here.
     */
    public $tab_name_index = array(
        'vtiger_crmentity' => 'crmid',
        'its4you_cashflow4you' => 'cashflow4youid',
        'its4you_cashflow4youcf' => 'cashflow4youid'
    );

    /**
     * Mandatory for Listing (Related listview)
     */
    public $list_fields = array(
        // tablename should not have prefix 'vtiger_'
        'Cashflow4You No' => array('cashflow' => 'cashflow4you_no'),
        'Cashflow4You Name' => array('cashflow' => 'cashflow4youname'),
        'Relation' => array('cashflow' => 'relationid'),
        'Paid Amount' => array('cashflow' => 'paymentamount'),
        'Due Date' => array('cashflow' => 'due_date'),
        'Payment Date' => array('cashflow' => 'paymentdate'),
        'Payment Status' => array('cashflow' => 'cashflow4you_status'),
        'Payment Method' => array('cashflow' => 'cashflow4you_paymethod')
    );

    public $list_fields_name = array(
        /* Format: Field Label => fieldname */
        'Cashflow4You No' => 'cashflow4you_no',
        'Cashflow4You Name' => 'cashflow4youname',
        'Relation' => 'relationid',
        'Paid Amount' => 'paymentamount',
        'Due Date' => 'due_date',
        'PaymentDate' => 'paymentdate',
        'Payment Status' => 'cashflow4you_status',
        'Payment Method' => 'cashflow4you_paymethod',
        //'Assigned To' => 'assigned_user_id'
    );

    // Make the field link to detail view
    public $list_link_field = 'cashflow4youname';

    // For Popup listview and UI type support
    public $search_fields = array(
        /* Format: Field Label => Array(tablename, columnname) */
        // tablename should not have prefix 'vtiger_'
        'Cashflow4You No' => array('cashflow4you', 'cashflow4you_no'),
        'Assigned To' => array('vtiger_crmentity', 'assigned_user_id'),
    );

    public $search_fields_name = array(
        /* Format: Field Label => fieldname */
        'Cashflow4You Name' => 'cashflow4youname',
        'Assigned To' => 'assigned_user_id',
    );

    // For Popup window record selection
    public $popup_fields = array('cashflow4youname');

    // For Alphabetical search
    public $def_basicsearch_col = 'cashflow4youname';

    // Column value to use on detail view record text display
    public $def_detailview_recname = 'cashflow4youname';

    // Used when enabling/disabling the mandatory fields for the module.
    // Refers to vtiger_field.fieldname values.
    public $mandatory_fields = array('createdtime', 'modifiedtime', 'cashflow4youname');

    public $default_order_by = 'paymentdate';
    public $default_sort_order = 'DESC';

    public $related_tables = array('its4you_cashflow4youcf' => array('cashflow4youid'));
    /**
     * @var array
     * [Module, RelatedModule, RelatedLabel, RelatedActions, RelatedFunction]
     */
    public $registerRelatedLists = array(
        ['Cashflow4You', 'Documents', 'Documents', 'ADD,SELECT', 'get_attachments'],
        ['Cashflow4You', 'Invoice', 'Invoice', '', 'get_invoice'],
        ['Accounts', 'Cashflow4You', 'Cashflow4You', '', 'get_dependents_list', 'relatedto'],
        ['Contacts', 'Cashflow4You', 'Cashflow4You', '', 'get_dependents_list', 'contactid'],
        ['Vendors', 'Cashflow4You', 'Cashflow4You', '', 'get_dependents_list', 'relatedto'],
    );
    /**
     * [module, type, label, url, icon, sequence, handlerInfo]
     * @return array
     */
    public $registerCustomLinks = array(
        ['Cashflow4You', 'HEADERSCRIPT', 'Cashflow4You_Actions_Js', 'layouts/v7/modules/Cashflow4You/resources/Cashflow4YouActions.js']
    );
    /**
     * @var array
     * [name, handler, frequency, module, sequence, description]
     */
    public $registerCron = array(
        ['Cashflow4You', 'modules/Cashflow4You/cron/Cashflow4You.service', 86400, 'Cashflow4You', 0, 'Recommended frequency for actualize Cashflow4You is 1 day'],
    );
    /**
     * [event, file, class, condition, dependOn, modules]
     */
    public $registerEventHandler = array(
        array(
            'vtiger.entity.aftersave.final',
            'modules/Cashflow4You/actions/Cashflow4YouRelationHandler.php',
            'Cashflow4YouRelationHandler',
        ),
        array(
            'vtiger.entity.afterdelete',
            'modules/Cashflow4You/actions/Cashflow4YouDeleteRelHandler.php',
            'Cashflow4YouDeleteRelHandler'
        )
    );
    public $availableModules;
    private $Related_Modules_List = array("Invoice", "PurchaseOrder", "SalesOrder");
    private $Dependents_Module_List = array(
        "Accounts",
        "Contacts",
        "Potentials",
        "Vendors",
        "ITS4YouPreInvoice",
        "CreditNotes4You"
    );
    private $AddPayments_Module_List = array(
        "Invoice",
        "PurchaseOrder",
        "SalesOrder",
        "Potentials",
        "ITS4YouPreInvoice",
        "CreditNotes4You"
    );

    public function __construct()
    {
        global $log;

        $this->column_fields = getColumnFields(get_class($this));
        $this->db = PearDatabase::getInstance();
        $this->log = $log;
    }

    // ITS4YOU-CR SlOl 7/26/2011 

    public static function getWidget($name)
    {
        if ($name == 'Payments' &&
            isPermitted('ModComments', 'DetailView') == 'yes') {
            require_once dirname(__FILE__) . '/widgets/DetailViewBlockComment.php';
            return (new ModComments_DetailViewBlockCommentWidget());
        }
        return false;
    }

    /**
     * @throws Exception
     */
    public function save_module($module)
    {
        global $current_user;

        $this->db = PearDatabase::getInstance();
        $cashFlowId = $this->id;
        $vatAmount = CurrencyField::convertToDBFormat($this->column_fields['vat_amount'], $current_user, true);
        $paymentAmount = CurrencyField::convertToDBFormat($this->column_fields['paymentamount'], $current_user, true);
        $withoutTax = abs($paymentAmount) - abs($vatAmount);
        $paymentAmountMain = $paymentAmount;

        if ($this->column_fields['currency_id'] != CurrencyField::getDBCurrencyId()) {
            $currencyRateAndSymbol = getCurrencySymbolandCRate($this->column_fields['currency_id']);
            $paymentAmountMain = CurrencyField::convertToDollar($paymentAmountMain, $currencyRateAndSymbol['rate']);
        }

        $status = $this->getStatus();
        $conversionRate = Cashflow4You_Module_Model::getConversionRate($this->column_fields['currency_id']);
        $withoutTax = number_format($withoutTax, getCurrencyDecimalPlaces(), '.', '');

        self::updateRecord($cashFlowId, [
            'total_without_vat' => $withoutTax,
            'cashflow4you_status' => $status,
            'payamount_main' => $paymentAmountMain,
            'conversion_rate' => $conversionRate,
        ]);

        $relationModel = new Cashflow4You_Relation_Model();

        // set relation data
        if (isset($this->column_fields['relationid']) && !empty($this->column_fields['relationid'])) {
            $relationId = $this->column_fields['relationid'];
            $relationModule = getSalesEntityType($relationId);
            $relationModel->updateRelations($relationModule, $cashFlowId, $relationId);
            $associatedCount = $relationModel->countAssociatedTo($cashFlowId);

            if (!in_array($relationModule, ['SalesOrder', 'ITS4YouPreInvoice'])) {
                if ($associatedCount) {
                    $relationModel->updateCashFlowAssociatedTo($cashFlowId, array(
                        'partial_amount' => $paymentAmount,
                        'cashflow4you_associated_id' => $relationId,
                    ));
                } else {
                    $relationModel->saveAssociatedTo($cashFlowId, $relationId, $paymentAmount);
                }
            } else {
                if ($associatedCount) {
                    $relationModel->updateCashFlowAssociatedTo($cashFlowId, array(
                        'partial_amount' => $paymentAmount,
                    ));
                    $relationModel->updateSavedRelations($cashFlowId);
                }
            }

            $relationModel->updateSavedRelation($relationModule, $relationId, $cashFlowId);
        } elseif (isset($_REQUEST['idstring']) && !empty($_REQUEST['idstring'])) {
            $idList = explode(';', $_REQUEST['idstring']);
            $relationModel->updateRelations($_REQUEST['sourcemodule'], $_REQUEST['currentid'], '');

            foreach ($idList as $invoiceId) {
                $paymentAmount = CurrencyField::convertToDBFormat($_REQUEST['payment_' . $invoiceId], $current_user, true);

                if (!empty($_REQUEST['record'])) {
                    $relationModel->updateAssociatedTo($_REQUEST['record'], $invoiceId, $paymentAmount);
                } else {
                    $relationModel->saveAssociatedTo($_REQUEST['currentid'], $invoiceId, $paymentAmount);
                }
            }

            $relationModel->SavePaymentFromRelation();
        }

        $relationModel->updateRelationsField($cashFlowId);

        if (empty($_REQUEST['return_module'])) {
            $_REQUEST['return_module'] = $_REQUEST['module'];
        }

        if (empty($_REQUEST['return_id'])) {
            $_REQUEST['return_id'] = $_REQUEST['currentid'];
        }
    }

    /**
     * @return string
     */
    public function getStatus()
    {
        $columns = $this->column_fields;
        $currentDate = date_create('now');

        if (!empty($columns['paymentdate'])) {
            if (date_create(DateTimeField::convertToDBFormat($columns['paymentdate'])) <= $currentDate) {
                return 'Incoming' === $columns['cashflow4you_paytype'] ? 'Received' : 'Paid';
            } else {
                return 'Waiting';
            }
        }

        if (!empty($columns['due_date'])) {
            if (date_create(DateTimeField::convertToDBFormat($columns['due_date'])) >= $currentDate) {
                return 'Waiting';
            } else {
                return 'Pending';
            }
        }

        return 'Created';
    }

    /**
     * @param int $record
     * @param array $params
     */
    public static function updateRecord($record, $params)
    {
        $sql = sprintf(
            'UPDATE its4you_cashflow4you SET %s=? WHERE cashflow4youid=?',
            implode('=?, ', array_keys($params))
        );
        $params[] = $record;

        PearDatabase::getInstance()->pquery($sql, $params);
    }

    /**
     * Handle saving related module information.
     * NOTE: This function has been added to CRMEntity (base class).
     * You can override the behavior by re-defining it here.
     */
    public function save_related_module($module, $crmid, $with_module, $with_crmid)
    {
        if (!in_array($with_module, [''])) {
            parent::save_related_module($module, $crmid, $with_module, $with_crmid);

            return;
        }
        /**
         * $_REQUEST['action']=='Save' when choosing ADD from Related list.
         * Do nothing on the payment's entity when creating a related new child using ADD in relatedlist
         * by doing nothing we do not insert any line in the crmentity's table when
         * we are relating a module to this module
         */
        if ($_REQUEST['action'] != 'updateRelations') {
            return;
        }
        $_REQUEST['submode'] = 'no_html_conversion';
        //update the child elements' column value for uitype10
        $destinationModule = vtlib_purify($_REQUEST['destination_module']);
        if (!is_array($with_crmid)) {
            $with_crmid = [$with_crmid];
        }
        foreach ($with_crmid as $relcrmid) {
            $child = CRMEntity::getInstance($destinationModule);
            $child->retrieve_entity_info($relcrmid, $destinationModule);
            $child->mode = 'edit';
            $child->column_fields['cashflow4youid'] = $crmid;
            $child->save($destinationModule, $relcrmid);
        }
    }

    public function get_invoice($id, $cur_tab_id, $rel_tab_id, $actions = false)
    {
        global $log, $singlepane_view, $currentModule, $current_user;
        $log->debug("Entering get_invoice(" . $id . ") method ...");
        $this_module = $currentModule;

        $related_module = vtlib_getModuleNameById($rel_tab_id);
        require_once("modules/$related_module/$related_module.php");
        $other = new $related_module();
        vtlib_setup_modulevars($related_module, $other);
        $singular_modname = vtlib_toSingular($related_module);

        $parenttab = getParentTab();

        if ($singlepane_view == 'true') {
            $returnset = '&return_module=' . $this_module . '&return_action=DetailView&return_id=' . $id;
        } else {
            $returnset = '&return_module=' . $this_module . '&return_action=CallRelatedList&return_id=' . $id;
        }

        $button = '';

        if ($actions) {
            if (is_string($actions)) {
                $actions = explode(',', strtoupper($actions));
            }
            if (in_array('SELECT', $actions) && isPermitted($related_module, 4, '') == 'yes') {
                $button .= "<input title='" . getTranslatedString('LBL_SELECT') . " " . getTranslatedString($related_module) . "' class='crmbutton small edit' type='button' onclick=\"return window.open('index.php?module=$related_module&return_module=$currentModule&action=Popup&popuptype=detailview&select=enable&form=EditView&form_submit=false&recordid=$id&parenttab=$parenttab','test','width=640,height=602,resizable=0,scrollbars=0');\" value='" . getTranslatedString('LBL_SELECT') . " " . getTranslatedString($related_module) . "'>&nbsp;";
            }
            if (in_array('ADD', $actions) && isPermitted($related_module, 1, '') == 'yes') {
                $button .= "<input title='" . getTranslatedString('LBL_ADD_NEW') . " " . getTranslatedString($singular_modname) . "' class='crmbutton small create'" .
                    " onclick='this.form.action.value=\"EditView\";this.form.module.value=\"$related_module\"' type='submit' name='button'" .
                    " value='" . getTranslatedString('LBL_ADD_NEW') . " " . getTranslatedString($singular_modname) . "'>&nbsp;";
            }
        }

        $query = "SELECT vtiger_crmentity.*, vtiger_invoice.*, its4you_cashflow4you.cashflow4youname, 
                CASE WHEN (vtiger_users.user_name not like '') 
                THEN vtiger_users.user_name 
                ELSE vtiger_groups.groupname 
                END
                AS user_name FROM vtiger_invoice 
                LEFT JOIN vtiger_invoicecf ON vtiger_invoicecf.invoiceid = vtiger_invoice.invoiceid
			          LEFT JOIN vtiger_invoicebillads ON vtiger_invoicebillads.invoicebilladdressid = vtiger_invoice.invoiceid
			          LEFT JOIN vtiger_invoiceshipads ON vtiger_invoiceshipads.invoiceshipaddressid = vtiger_invoice.invoiceid
                INNER JOIN vtiger_crmentity ON vtiger_crmentity.crmid=vtiger_invoice.invoiceid 
                INNER JOIN vtiger_crmentityrel ON vtiger_crmentityrel.relcrmid=vtiger_crmentity.crmid 
                INNER JOIN its4you_cashflow4you ON vtiger_crmentityrel.crmid=its4you_cashflow4you.cashflow4youid
                LEFT JOIN vtiger_users ON vtiger_users.id=vtiger_crmentity.smownerid
                LEFT JOIN vtiger_groups ON vtiger_groups.groupid=vtiger_crmentity.smownerid 
                WHERE vtiger_crmentity.deleted=0 AND its4you_cashflow4you.cashflow4youid=" . $id;
        $return_value = GetRelatedList($this_module, $related_module, $other, $query, $button, $returnset);

        if ($return_value == null) {
            $return_value = array();
        }
        $return_value['CUSTOM_BUTTON'] = $button;

        $log->debug("Exiting get_invoice method ...");

        return $return_value;
    }

    public function getListQuery($module, $where = '')
    {
        $query = "SELECT vtiger_crmentity.*, $this->table_name.*";

        // Select Custom Field Table Columns if present
        if (!empty($this->customFieldTable)) {
            $query .= ", " . $this->customFieldTable[0] . ".* ";
        }

        $query .= " FROM $this->table_name";

        $query .= "	INNER JOIN vtiger_crmentity ON vtiger_crmentity.crmid = $this->table_name.$this->table_index";

        // Consider custom table join as well.
        if (!empty($this->customFieldTable)) {
            $query .= " INNER JOIN " . $this->customFieldTable[0] . " ON " . $this->customFieldTable[0] . '.' . $this->customFieldTable[1] .
                " = $this->table_name.$this->table_index";
        }
        $query .= " LEFT JOIN vtiger_users ON vtiger_users.id = vtiger_crmentity.smownerid";
        $query .= " LEFT JOIN vtiger_groups ON vtiger_groups.groupid = vtiger_crmentity.smownerid";

        $linkedModulesQuery = $this->db->pquery(
            "SELECT distinct fieldname, columnname, relmodule FROM vtiger_field" .
            " INNER JOIN vtiger_fieldmodulerel ON vtiger_fieldmodulerel.fieldid = vtiger_field.fieldid" .
            " WHERE uitype='10' AND vtiger_fieldmodulerel.module=?",
            [$module]
        );
        $linkedFieldsCount = $this->db->num_rows($linkedModulesQuery);

        for ($i = 0; $i < $linkedFieldsCount; $i++) {
            $related_module = $this->db->query_result($linkedModulesQuery, $i, 'relmodule');
            $fieldname = $this->db->query_result($linkedModulesQuery, $i, 'fieldname');
            $columnname = $this->db->query_result($linkedModulesQuery, $i, 'columnname');

            $other = CRMEntity::getInstance($related_module);
            vtlib_setup_modulevars($related_module, $other);

            $query .= " LEFT JOIN $other->table_name ON $other->table_name.$other->table_index =" .
                "$this->table_name.$columnname";
        }

        global $current_user;
        $query .= $this->getNonAdminAccessControlQuery($module, $current_user);
        $query .= "WHERE vtiger_crmentity.deleted = 0 " . $where;

        return $query;
    }

    /**
     * @param $moduleName
     * @param $eventType
     * @throws Exception
     */
    public function vtlib_handler($moduleName, $eventType)
    {
        include_once 'modules/ModComments/ModComments.php';
        include_once 'modules/ModTracker/ModTracker.php';

        $this->module = Vtiger_Module_Model::getInstance($moduleName);

        switch ($eventType) {
            case 'module.postinstall':
            case 'module.enabled':
                $this->updateCron();
            case 'module.postupdate':
                $this->addCustomLinks();
                break;
            case 'module.disabled':
            case 'module.preuninstall':
                $this->updateCron(false);
            case 'module.preupdate':
                $this->deleteCustomLinks();
                break;
        }
    }

    public function updateCron($register = true)
    {
        $this->db->pquery('ALTER TABLE vtiger_cron_task MODIFY COLUMN id INT auto_increment ');

        foreach ($this->registerCron as $cronInfo) {
            list($name, $handler, $frequency, $module, $sequence, $description) = $cronInfo;

            Vtiger_Cron::deregister($name);

            if ($register) {
                Vtiger_Cron::register($name, $handler, $frequency, $module, 1, $sequence, $description);
            }
        }
    }

    /**
     * @throws Exception
     */
    public function addCustomLinks()
    {
        $this->updateNumbering();
        $this->setPicklistDependency();
        $this->updatePayTypePresence();
        $this->updateFields();
        $this->updateModuleSettings();

        $this->updateTables();
        $this->updateCurrencyUIType();
        $this->updateRelatedList();
        $this->updateCustomLinks();
        $this->updateEventHandler();
        $this->showCashflowInformation();
        $this->updateStatusPicklist();

        Cashflow4You_Integration_Model::updateAvailableModules();

        Settings_MenuEditor_Module_Model::addModuleToApp($this->moduleName, $this->parentName);

        ModTracker::enableTrackingForModule(getTabid($this->moduleName));
        ModComments::addWidgetTo([$this->moduleName]);

        $this->changeDecimalsTo8();
    }

    private function updateNumbering()
    {
        $this->setModuleSeqNumber('configure', $this->moduleName, 'PAY', 1);
        $this->updateMissingSeqNumber($this->moduleName);
    }

    private function setPicklistDependency()
    {
        //set picklist dependency
        $DependencyTab = [
            [
                'sourcefield' => 'cashflow4you_cash',
                'targetfield' => 'cashflow4you_paymethod',
                'sourcevalue' => 'Cashflow',
                'targetvalues' => '["Cash","Other"]'
            ],
            [
                'sourcefield' => 'cashflow4you_cash',
                'targetfield' => 'cashflow4you_paymethod',
                'sourcevalue' => 'Bank account',
                'targetvalues' => '["Bank Transfer","Credit card","Google Checkout","Paypal","Wire transfer"]'
            ],
            [
                'sourcefield' => 'cashflow4you_category',
                'targetfield' => 'cashflow4you_subcategory',
                'sourcevalue' => 'Income for services',
                'targetvalues' => '["Extensions"]'
            ],
            [
                'sourcefield' => 'cashflow4you_category',
                'targetfield' => 'cashflow4you_subcategory',
                'sourcevalue' => 'Income for products',
                'targetvalues' => '["Programming"]'
            ],
            [
                'sourcefield' => 'cashflow4you_category',
                'targetfield' => 'cashflow4you_subcategory',
                'sourcevalue' => 'Office cost',
                'targetvalues' => '["Telephone"]'
            ],
            [
                'sourcefield' => 'cashflow4you_category',
                'targetfield' => 'cashflow4you_subcategory',
                'sourcevalue' => 'Telephone',
                'targetvalues' => '["none"]'
            ],
            [
                'sourcefield' => 'cashflow4you_category',
                'targetfield' => 'cashflow4you_subcategory',
                'sourcevalue' => 'Salaries',
                'targetvalues' => '["none"]'
            ],
            [
                'sourcefield' => 'cashflow4you_category',
                'targetfield' => 'cashflow4you_subcategory',
                'sourcevalue' => 'Wages',
                'targetvalues' => '["none"]'
            ],
            [
                'sourcefield' => 'cashflow4you_category',
                'targetfield' => 'cashflow4you_subcategory',
                'sourcevalue' => 'Rent',
                'targetvalues' => '["none"]'
            ],
            [
                'sourcefield' => 'cashflow4you_category',
                'targetfield' => 'cashflow4you_subcategory',
                'sourcevalue' => 'Fuel',
                'targetvalues' => '["Auto"]'
            ],
            [
                'sourcefield' => 'cashflow4you_category',
                'targetfield' => 'cashflow4you_subcategory',
                'sourcevalue' => 'Other',
                'targetvalues' => '[]'
            ]
        ];
        $module = Vtiger_Module::getInstance($this->moduleName);
        $id = $module->id;
        $insert = 'INSERT INTO vtiger_picklist_dependency (id,tabid,sourcefield,targetfield,sourcevalue,targetvalues) VALUES (?,?,?,?,?,?)';
        $query = 'SELECT MAX(id) AS id FROM vtiger_picklist_dependency';
        $result = $this->db->pquery($query, array());
        $curr_id = $this->db->query_result($result, 0, 'id');

        foreach ($DependencyTab as $Value) {
            $query = 'SELECT * FROM vtiger_picklist_dependency WHERE tabid=? AND sourcefield=? AND targetfield=? AND sourcevalue=?';
            $result1 = $this->db->pquery($query, array(
                $id,
                $Value['sourcefield'],
                $Value['targetfield'],
                $Value['sourcevalue'],
            ));

            if ($this->db->num_rows($result1) == 0) {
                $curr_id = $this->db->getUniqueID('vtiger_picklist_dependency');
                $this->db->pquery($insert, array(
                    $curr_id,
                    $id,
                    $Value['sourcefield'],
                    $Value['targetfield'],
                    $Value['sourcevalue'],
                    $Value['targetvalues']
                ));
            }
        }

        if (!empty($curr_id)) {
            $this->db->pquery('UPDATE vtiger_picklist_dependency_seq SET id=?', array($curr_id));
        }
    }

    public function updatePayTypePresence()
    {
        $this->db->pquery(
            'UPDATE vtiger_cashflow4you_paytype SET `presence`=? WHERE cashflow4you_paytype=? OR cashflow4you_paytype=?',
            array('0', 'Incoming', 'Outgoing')
        );
    }

    public function updateFields()
    {
        $this->db->pquery(
            'UPDATE vtiger_field SET typeofdata=? WHERE columnname=? AND tabid=?',
            ['V~M', 'smownerid', getTabid($this->moduleName)]
        );
        $this->db->pquery(
            'UPDATE vtiger_field SET typeofdata=? WHERE tabid=? AND columnname IN(?,?)',
            ['DT~O', getTabid($this->moduleName), 'createdtime', 'modifiedtime']
        );
    }

    public function updateModuleSettings()
    {
        $tabId = getTabId($this->moduleName);
        $fieldLabels = array(
            'cashflow4youname' => 'Cashflow4You Name',
            'cashflow4you_no' => 'Cashflow4You No',
            'paymentdate' => 'Payment Date',
            'cashflow4you_paymethod' => 'Payment Method',
            'paymentamount' => 'Paid Amount',
            'relationid' => 'Relation',
            'transactionid' => 'Transaction ID',
            'due_date' => 'Due Date',
            'currency_id' => 'Currency',
            'cashflow4you_paytype' => 'Payment Type',
            'cashflow4you_category' => 'Payment Category',
            'relatedto' => 'Related To',
            'cashflow4you_cash' => 'Payment Mode',
            'cashflow4you_subcategory' => 'Payment Subcategory',
            'cashflow4you_status' => 'Payment Status',
            'accountingdate' => 'Accounting Date',
            'vat_amount' => 'VAT',
            'total_without_vat' => 'Price without VAT',
            'tax_expense' => 'Tax Component',
            'cashflow4you_associated_no' => 'Associated No',
            'createdtime' => 'Created Time',
            'modifiedtime' => 'Modified Time',
            'description' => 'Description',
            'smownerid' => 'Assigned To'
        );

        foreach ($fieldLabels as $column => $label) {
            $this->db->pquery(
                'UPDATE vtiger_field SET fieldlabel=? WHERE tabid=? AND vtiger_field.columnname=? AND fieldname!=?',
                array($label, $tabId, $column, $label)
            );
        }

        $field = Vtiger_Field_Model::getInstance('contact_id', $this->module);

        if ($field) {
            $field->setRelatedModules(['Contacts']);
        }
    }

    public function updateTables()
    {
        $this->db->query(
            'CREATE TABLE IF NOT EXISTS `its4you_cashflow4you_integration` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `module` varchar(50) DEFAULT NULL,
            `active` varchar(10) DEFAULT NULL,
            `status_field` varchar(100) DEFAULT NULL,
            `status_value` varchar(255) DEFAULT NULL,
            `status_value_back` varchar(255) DEFAULT NULL,
            `relatedto_field` varchar(100) DEFAULT NULL,
            `total_field` varchar(100) DEFAULT NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `module` (`module`)
            )'
        );
    }

    public function updateCurrencyUIType()
    {
        $this->db->pquery('UPDATE vtiger_ws_fieldtype SET fieldtype = ? WHERE uitype = ?', ['currencyList', 117]);
    }

    public function changeDecimalsTo8()
    {
        $sqls = [
            'ALTER TABLE `its4you_cashflow4you` MODIFY COLUMN `paymentamount` DECIMAL(25,8) NULL DEFAULT NULL AFTER `cashflow4you_paymethod`, CHANGE COLUMN `payamount_main` `payamount_main` DECIMAL(25,8) NULL DEFAULT NULL AFTER `currency_id`, CHANGE COLUMN `vat_amount` `vat_amount` DECIMAL(25,8) NULL DEFAULT NULL AFTER `accountingdate`, CHANGE COLUMN `total_without_vat` `total_without_vat` DECIMAL(25,8) NULL DEFAULT NULL AFTER `vat_amount`',
            'ALTER TABLE `its4you_cashflow4you_associatedto` MODIFY COLUMN `partial_amount` DECIMAL(25,8) NULL DEFAULT NULL AFTER `cashflow4you_associated_id`',
            'ALTER TABLE `vtiger_invoice` MODIFY COLUMN `p_paid_amount` DECIMAL(25,8) NULL DEFAULT NULL AFTER `region_id`, MODIFY COLUMN `p_open_amount` DECIMAL(25,8) NULL DEFAULT NULL AFTER `p_paid_amount`',
        ];

        foreach ($sqls as $sql) {
            $this->db->pquery($sql);
        }
    }

    /**
     * @param bool $register
     */
    public function updateRelatedList($register = true)
    {
        foreach ($this->registerRelatedLists as $relatedList) {
            $module = Vtiger_Module::getInstance($relatedList[0]);
            $relatedModule = Vtiger_Module::getInstance($relatedList[1]);

            if ($module && $relatedModule) {
                $relatedLabel = isset($relatedList[2]) ? $relatedList[2] : $relatedModule->name;
                $relatedActions = isset($relatedList[3]) ? $relatedList[3] : '';
                $relatedFunction = isset($relatedList[4]) ? $relatedList[4] : 'get_related_list';
                $field = isset($relatedList[5]) ? Vtiger_Field_Model::getInstance($relatedList[5], $relatedModule) : '';
                $fieldId = $field ? $field->getId() : '';

                $module->unsetRelatedList($relatedModule, $relatedLabel);
                $module->unsetRelatedList($relatedModule, $relatedLabel, $relatedFunction);

                if ($register) {
                    $module->setRelatedList($relatedModule, $relatedLabel, $relatedActions, $relatedFunction, $fieldId);
                }
            }
        }
    }

    /**
     * @param bool $register
     */
    public function updateCustomLinks($register = true)
    {
        foreach ($this->registerCustomLinks as $customLink) {
            $module = Vtiger_Module::getInstance($customLink[0]);
            $type = $customLink[1];
            $label = $customLink[2];
            $url = str_replace('$LAYOUT$', Vtiger_Viewer::getDefaultLayoutName(), $customLink[3]);

            if ($module) {
                $module->deleteLink($type, $label);

                if ($register) {
                    $module->addLink($type, $label, $url, $customLink[4], $customLink[5], $customLink[6]);
                }
            }
        }
    }

    /**
     * @param bool $register
     */
    public function updateEventHandler($register = true)
    {
        $eventsManager = new VTEventsManager($this->db);

        foreach ($this->registerEventHandler as $data) {
            list($events, $fileName, $className, $condition, $dependOn, $modules) = $data;

            $eventsManager->unregisterHandler($className);

            if ($register) {
                $condition = !empty($condition) ? $condition : '';
                $dependOn = !empty($dependOn) ? $dependOn : '[]';

                foreach ((array)$events as $event) {
                    $eventsManager->registerHandler($event, $fileName, $className, $condition, $dependOn);

                    foreach ((array)$modules as $module) {
                        $eventsManager->setModuleForHandler($module, $className);
                    }
                }
            }
        }
    }

    public function showCashflowInformation()
    {
        $this->db->pquery(
            'UPDATE vtiger_field SET presence=?, displaytype=? WHERE columnname=? OR columnname=?',
            [2, 2, 'p_paid_amount', 'p_open_amount']
        );
    }

    public function updateStatusPicklist()
    {
        $module = Vtiger_Module_Model::getInstance($this->moduleName);
        $field = Vtiger_Field_Model::getInstance('cashflow4you_status', $module);

        if ($field) {
            $picklistValues = array_values(Vtiger_Util_Helper::getPickListValues('cashflow4you_status'));
            $newPicklistValues = array(
                'Created',
                'Waiting',
                'Pending',
                'Received',
                'Paid',
            );

            if ($picklistValues !== $newPicklistValues) {
                $this->db->query('TRUNCATE vtiger_cashflow4you_status');
                $field->setPicklistValues($newPicklistValues);
            }
        }
    }

    /**
     * @throws Exception
     */
    public function deleteCustomLinks()
    {
        $this->updateTables();
        $this->hideCashflowInformation();
        $this->updateRelatedList(false);
        $this->updateCustomLinks(false);
        $this->updateEventHandler(false);

        Cashflow4You_Integration_Model::updateAvailableModules(false);

        ModTracker::disableTrackingForModule(getTabid($this->moduleName));
        ModComments::removeWidgetFrom([$this->moduleName]);
    }

    public function hideCashflowInformation()
    {
        $this->db->pquery('UPDATE vtiger_field SET presence=?, displaytype=? WHERE columnname=? OR columnname=?', [1, 3, 'p_paid_amount', 'p_open_amount']);
    }

    public function addEventHandler()
    {
        $adb = PearDatabase::getInstance();
        $event_classname = "Cashflow4YouRelationHandler";

        $eventsManager = new VTEventsManager($adb);

        $eventsManager->unregisterHandler("Cashflow4YouRelationHandler");
        $eventsManager->unregisterHandler("Cashflow4YouDeleteRelHandler");

        // register aftersave handler for Invoice & PurchaseOrder
        $event_eventname = "vtiger.entity.aftersave.final";
        $event_filename = "modules/Cashflow4You/actions/Cashflow4YouRelationHandler.php";
        $eventsManager->registerHandler($event_eventname, $event_filename, $event_classname, '');

        $eventsManager->setModuleForHandler("Invoice", $event_classname);
        $eventsManager->setModuleForHandler("PurchaseOrder", $event_classname);
        $eventsManager->setModuleForHandler("SalesOrder", $event_classname);

        // register afterdelete handler for Invoice & PurchaseOrder & SalesOrder
        $event_filename = "modules/Cashflow4You/actions/Cashflow4YouDeleteRelHandler.php";
        $eventsManager->registerHandler(
            "vtiger.entity.afterdelete",
            $event_filename,
            "Cashflow4YouDeleteRelHandler",
            ''
        );
    }

    /**
     * @throws Exception
     */
    public function retrieveRelatedList()
    {
        if (!$this->availableModules) {
            $this->retrieveAvailableModules();
        }

        /** @var Cashflow4You_Integration_Model $availableModule */
        foreach ($this->availableModules as $availableModule) {
            $relateModule = $availableModule->get('module');

            if ($availableModule->isActive() && 'Invoice' !== $relateModule) {
                $this->registerRelatedLists[] = array(
                    $relateModule,
                    $this->moduleName,
                    $this->moduleName,
                    '',
                    'get_dependents_list',
                );
            }
        }
    }

    /**
     * @throws Exception
     */
    public function retrieveAvailableModules()
    {
        $this->availableModules = Cashflow4You_Integration_Model::getAvailableModules();
    }

    /**
     * @throws Exception
     */
    public function retrieveCustomLinks()
    {
        if (!$this->availableModules) {
            $this->retrieveAvailableModules();
        }

        /** @var Cashflow4You_Integration_Model $availableModule */
        foreach ($this->availableModules as $availableModule) {
            $relateModule = $availableModule->get('module');

            if ($availableModule->isActive()) {
                $this->registerCustomLinks[] = array(
                    $relateModule,
                    'DETAILVIEW',
                    'Add Payment',
                    'index.php?module=Cashflow4You&view=Edit&relationid=$RECORD$&sourceModule=$MODULE$&sourceRecord=$RECORD$&relationOperation=1',
                );
                $this->registerCustomLinks[] = array(
                    $relateModule,
                    'DETAILVIEW',
                    'Payments',
                    'javascript:Cashflow4You_Actions_Js.showPayments(this);',
                );

                if ('Invoice' === $relateModule) {
                    $this->registerCustomLinks[] = array(
                        $relateModule,
                        'LISTVIEWBASIC',
                        'Create Payment',
                        'javascript:Cashflow4You_Actions_Js.CreatePayment("index.php?module=Cashflow4You&view=CreatePaymentActionAjax&mode=showCreatePaymentForm");',
                    );
                    $this->registerCustomLinks[] = array(
                        $relateModule,
                        'LISTVIEWMASSACTION',
                        'Create Payment',
                        'javascript:Cashflow4You_Actions_Js.CreatePayment("index.php?module=Cashflow4You&view=CreatePaymentActionAjax&mode=showCreatePaymentForm");',
                    );
                }
            }
        }
    }


    /**
     * @throws Exception
     */
    public function getRequirementIntegration()
    {
        if (!$this->availableModules) {
            $this->retrieveAvailableModules();
        }

        $info = array();

        /**
         * @var Cashflow4You_Integration_Model $availableModule
         */
        foreach ($this->availableModules as $availableModule) {
            $module = $availableModule->get('module');

            if ($availableModule->isActive()) {
                $moduleModel = $availableModule->getModule();
                $message = '';
                $field1 = Vtiger_Field_Model::getInstance('paidamount', $moduleModel);
                $field2 = Vtiger_Field_Model::getInstance('openamount', $moduleModel);
                $data = array(
                    'module' => $module,
                    'field1' => $field1 ? vtranslate($field1->get('label'), $module) : '',
                    'field2' => $field2 ? vtranslate($field2->get('label'), $module) : '',
                );

                if (!$field1) {
                    $message = 'LBL_MISSING_PAID_AMOUNT';
                }
                if (!$field2) {
                    $message = 'LBL_MISSING_OPEN_AMOUNT';
                }
                if (!in_array($module, $availableModule->getRelationField()->getReferenceList())) {
                    $message = 'LBL_MISSING_MODULE_IN_REFERENCE_FIELD';
                }

                $data['validate'] = empty($message);
                $data['validate_message'] = vtranslate($message, $this->moduleName);

                array_push($info, $data);
            }
        }

        return $info;
    }

    public function getRequirementHeaders()
    {
        return array(
            vtranslate('LBL_MODULE', $this->moduleName) => 'module',
            vtranslate('LBL_PAID_AMOUNT', $this->moduleName) => 'field1',
            vtranslate('LBL_OPEN_AMOUNT', $this->moduleName) => 'field2',
        );
    }

    /**
     * @return array
     */
    public function getRequirementValidations()
    {
        return array(
            array(
                'type' => 'workflow',
                'label' => vtranslate('LBL_INTEGRATION', $this->moduleName),
                'function' => 'getRequirementIntegration',
            ),
        );
    }

    public function deleteRelatedLists()
    {
        $moduleName = $this->moduleName;
        $moduleInstance = Vtiger_Module::getInstance($moduleName);
        $relModuleList = array_merge($this->Related_Modules_List, $this->Dependents_Module_List);

        foreach ($relModuleList as $relModuleName) {
            $relModuleInstance = Vtiger_Module::getInstance($relModuleName);

            if ($relModuleInstance) {
                $relModuleInstance->unsetRelatedList($moduleInstance, $moduleName, 'get_related_list');
                $relModuleInstance->unsetRelatedList($moduleInstance, $moduleName, 'get_dependents_list');

                if (in_array($relModuleName, $this->AddPayments_Module_List)) {
                    $relModuleInstance->deleteLink('DETAILVIEW', 'Payments', 'javascript:Cashflow4You_Actions_Js.showPayments(this);');
                    $relModuleInstance->deleteLink('DETAILVIEW', 'Add Payment', 'index.php?module=Cashflow4You&view=Edit&relationid=$RECORD$&sourceModule=$MODULE$&relationOperation=1&sourceRecord=$RECORD$');
                    $relModuleInstance->deleteLink('LISTVIEWMASSACTION', 'Create Payment');
                    $relModuleInstance->deleteLink('LISTVIEWBASIC', 'Create Payment');
                }
            }
        }
    }

    /*
     * Function to get the primary query part of a report
     * @param - $module primary module name
     * returns the query string formed on fetching the related data for report for secondary module
     */

    public function generateReportsSecQuery($module, $secmodule, $queryPlanner)
    {
        $matrix = $queryPlanner->newDependencyMatrix();
        $matrix->setDependency(
            'vtiger_crmentityCashflow4You',
            array('vtiger_groupsCashflow4You', 'vtiger_usersCashflow4You', 'vtiger_lastModifiedByCashflow4You')
        );
        $matrix->setDependency('its4you_cashflow4you', array(
            'vtiger_crmentityCashflow4You',
            'its4you_cashflow4youcf',
            'its4you_cashflow4youCashflow4You',
            ' its4you_cashflow4you_associatedto'
        ));

        if (!$queryPlanner->requireTable('its4you_cashflow4you', $matrix)) {
            return '';
        }

        $query = $this->getRelationQuery($module, $secmodule, "its4you_cashflow4you", "cashflow4youid", $queryPlanner);

        $module_low = strtolower($module);

        if ($queryPlanner->requireTable('vtiger_crmentityCashflow4You', $matrix)) {
            $query .= " left join vtiger_crmentity as vtiger_crmentityCashflow4You on vtiger_crmentityCashflow4You.crmid=its4you_cashflow4you.cashflow4youid and vtiger_crmentityCashflow4You.deleted=0";
        }
        if ($queryPlanner->requireTable('its4you_cashflow4youcf')) {
            $query .= " left join its4you_cashflow4youcf on its4you_cashflow4you.cashflow4youid = its4you_cashflow4youcf.cashflow4youid";
        }
        if ($queryPlanner->requireTable('its4you_cashflow4you_associatedto')) {
            $query .= "	left join its4you_cashflow4you_associatedto as its4you_cashflow4you_associatedtoCashflow4You on its4you_cashflow4you_associatedtoCashflow4You.cashflow4youid = vtiger_crmentityCashflow4You.cashflow4youid";
        }
        if ($queryPlanner->requireTable('its4you_cashflow4youCashflow4You')) {
            $query .= "	left join its4you_cashflow4you as its4you_cashflow4youCashflow4You on its4you_cashflow4youCashflow4You.cashflow4youid = vtiger_crmentityCashflow4You.crmid";
        }
        if ($queryPlanner->requireTable('vtiger_groupsCashflow4You')) {
            $query .= "	left join vtiger_groups as vtiger_groupsCashflow4You on vtiger_groupsCashflow4You.groupid = vtiger_crmentityCashflow4You.smownerid";
        }
        if ($queryPlanner->requireTable('vtiger_usersCashflow4You')) {
            $query .= " left join vtiger_users as vtiger_usersCashflow4You on vtiger_usersCashflow4You.id = vtiger_crmentityCashflow4You.smownerid";
        }
        if ($queryPlanner->requireTable('vtiger_lastModifiedByCashflow4You')) {
            $query .= " left join vtiger_users as vtiger_lastModifiedByCashflow4You on vtiger_lastModifiedByCashflow4You.id = vtiger_crmentityCashflow4You.modifiedby ";
        }

        if ($queryPlanner->requireTable('vtiger_currency_infoCashflow4You')) {
            $query .= ' left join vtiger_currency_info as vtiger_currency_infoCashflow4You on vtiger_currency_infoCashflow4You.id = ' . $this->table_name . '.currency_id ';
        }

        if ($queryPlanner->requireTable("vtiger_accountRelCashflow4You")) {
            $query .= " left join vtiger_account as vtiger_accountRelCashflow4You on its4you_cashflow4you.relatedto = vtiger_accountRelCashflow4You.accountid AND vtiger_accountRelCashflow4You.accountid = its4you_cashflow4you.relatedto ";
        }
        if ($queryPlanner->requireTable("vtiger_vendorRelCashflow4You")) {
            $query .= " left join vtiger_vendor as vtiger_vendorRelCashflow4You on its4you_cashflow4you.relatedto = vtiger_vendorRelCashflow4You.vendorid AND vtiger_vendorRelCashflow4You.vendorid = its4you_cashflow4you.relatedto ";
        }
        if ($queryPlanner->requireTable("vtiger_contactdetailsRelCashflow4You")) {
            $query .= " left join vtiger_contactdetails as vtiger_contactdetailsRelCashflow4You on its4you_cashflow4you.contactid = vtiger_contactdetailsRelCashflow4You.contactid AND vtiger_contactdetailsRelCashflow4You.contactid = its4you_cashflow4you.contactid ";
        }

        return $query;
    }

    public function generateReportsQuery($module, $queryPlanner)
    {
        global $current_user;

        $thisModule = $this->moduleName;
        $thisTableName = $this->table_name;
        $thisTableIndex = $this->table_index;
        $customFieldTable = $this->customFieldTable[0];
        $customFieldTableIndex = $this->customFieldTable[1];

        $queryPlanner->newDependencyMatrix()->setDependency($thisTableName, array(
            $customFieldTable,
            'vtiger_crmentity' . $thisModule,
            'vtiger_account' . $thisModule,
            'vtiger_leaddetails' . $thisModule,
            'vtiger_potential' . $thisModule
        ));

        $query = "from its4you_cashflow4you inner join vtiger_crmentity on vtiger_crmentity.crmid=its4you_cashflow4you.cashflow4youid";

        if ($queryPlanner->requireTable("its4you_cashflow4youcf")) {
            $query .= " left join its4you_cashflow4youcf on $thisTableName.$thisTableIndex = $customFieldTable.$customFieldTableIndex";
        }
        if ($queryPlanner->requireTable("vtiger_usersCashflow4You")) {
            $query .= " left join vtiger_users as vtiger_usersCashflow4You on vtiger_usersCashflow4You.id = vtiger_crmentity.smownerid";
        }
        if ($queryPlanner->requireTable("vtiger_groupsCashflow4You")) {
            $query .= " left join vtiger_groups as vtiger_groupsCashflow4You on vtiger_groupsCashflow4You.groupid = vtiger_crmentity.smownerid";
        }
        if ($queryPlanner->requireTable("vtiger_createdby$thisModule")) {
            $query .= " left join vtiger_users as vtiger_createdby$thisModule on vtiger_createdby$thisModule.id = vtiger_crmentity.smcreatorid ";
        }
        if ($queryPlanner->requireTable("vtiger_lastModifiedBy$thisModule")) {
            $query .= " left join vtiger_users as vtiger_lastModifiedBy$thisModule on vtiger_lastModifiedBy$thisModule.id = vtiger_crmentity.modifiedby ";
        }

        $fieldName = "currency_id";
        $tableName = "its4you_cashflow4you";
        $requiredTables = [
            'vtiger_currency_info' => 'id',
        ];

        $this->generateCustomReportsQuery($fieldName, $tableName, $requiredTables, $queryPlanner, $query, '');

        $fieldName = "relationid";
        $tableName = "its4you_cashflow4you";
        $requiredTables = [
            'vtiger_purchaseorder' => 'purchaseorderid',
            'vtiger_salesorder' => 'salesorderid',
            'vtiger_invoice' => 'invoiceid',
            'vtiger_potential' => 'potentialid',
            'vtiger_creditnotes4you' => 'creditnotes4you_id',
            'its4you_preinvoice' => 'preinvoiceid',
        ];

        $this->generateCustomReportsQuery($fieldName, $tableName, $requiredTables, $queryPlanner, $query);

        $fieldName = "contactid";
        $requiredTables = [
            'vtiger_contactdetails' => 'contactid',
        ];

        $this->generateCustomReportsQuery($fieldName, $tableName, $requiredTables, $queryPlanner, $query);

        $fieldName = "relatedto";
        $requiredTables = [
            'vtiger_vendor' => 'vendorid',
            'vtiger_account' => 'accountid',
        ];

        $this->generateCustomReportsQuery($fieldName, $tableName, $requiredTables, $queryPlanner, $query);

        return $query;
    }

    public function generateCustomReportsQuery($fieldName, $tableName, $requiredTables, &$queryPlanner, &$query, $rel = 'Rel')
    {
        $thisModule = $this->moduleName;

        if ($rel) {
            $result = $this->db->pquery(
                "SELECT fieldid FROM vtiger_field WHERE columnname = ? AND tablename = ?",
                array($fieldName, $tableName)
            );
            $relFieldId = $this->db->query_result($result, 0, "fieldid");
        }

        foreach ($requiredTables as $requiredTable => $requiredField) {
            if ($queryPlanner->requireTable($requiredTable . $rel . $thisModule . $relFieldId)) {
                $customReuiredTableName = $requiredTable . $rel . $thisModule . $relFieldId;
                $query .= " left join $requiredTable as $customReuiredTableName on $tableName.$fieldName = $customReuiredTableName.$requiredField AND $customReuiredTableName.$requiredField = $tableName.$fieldName ";
            }
        }
    }

    public function fix()
    {
        $this->updateNumbering();
        $this->setPicklistDependency();
        $this->updatePayTypePresence();
    }

    /**
     * @throws Exception
     */
    private function addCashflowFields()
    {
        $modules = array(
            'Invoice',
            'SalesOrder',
            'PurchaseOrder',
            'Potentials',
            'ITS4YouPreInvoice',
            'CreditNotes4You',
        );

        foreach ($modules as $module) {
            $module = Vtiger_Module_Model::getInstance($module);

            if ($module) {
                $integrationModel = Cashflow4You_Integration_Model::getInstance($module);
                $integrationModel->save();

                if ($integrationModel->isActive()) {
                    $integrationModel->updateFields();
                } else {
                    $integrationModel->updateFields(false);
                }
            }
        }
    }

    private function checkRelatedList($tabid, $related_tabid, $label, $name = "get_related_list")
    {
        $adb = PearDatabase::getInstance();
        $result = $adb->pquery('SELECT relation_id FROM vtiger_relatedlists WHERE tabid=? AND related_tabid=? AND label=? AND name=?', array($tabid, $related_tabid, $label, $name));

        return $adb->num_rows($result);
    }

    private function DeleteDB()
    {
        $this->db->pquery("DELETE FROM `vtiger_fieldmodulerel` WHERE module=?", array('Cashflow4You'));
        $this->db->pquery("DELETE FROM `vtiger_modentity_num` WHERE `semodule` =?", array('Cashflow4you'));
        $this->db->pquery("DELETE FROM `vtiger_modtracker_relations` WHERE `targetmodule` =?", array('Cashflow4you'));

        $query = "DELETE FROM `vtiger_picklist` WHERE `name` = 'cashflow4you_cash' OR `name` = 'cashflow4you_category' OR `name` = 'cashflow4you_paymethod' OR `name` = 'cashflow4you_paytype' OR `name` = 'cashflow4you_status' OR `name` = 'cashflow4you_subcategory'";
        $this->db->pquery($query, array());

        $query = "DELETE FROM `vtiger_picklist_dependency` WHERE `sourcefield` = 'cashflow4you_cash' OR `sourcefield` = 'cashflow4you_category' OR `sourcefield` = 'cashflow4you_paymethod' OR `sourcefield` = 'cashflow4you_paytype' OR `sourcefield` = 'cashflow4you_status' OR `sourcefield` = 'cashflow4you_subcategory'";
        $this->db->pquery($query, array());
    }

    private function addCashflowInformation()
    {
        $this->db->pquery(
            "UPDATE vtiger_invoice SET p_open_amount=?, p_paid_amount=total, balance=?, received=total WHERE invoicestatus='Paid' AND p_open_amount IS NULL AND p_paid_amount IS NULL",
            array('0.000', '0.000')
        );
        $this->db->pquery(
            "UPDATE vtiger_invoice SET p_open_amount=total, p_paid_amount=?,balance=total, received=? WHERE invoicestatus!='Paid' AND p_open_amount IS NULL AND p_paid_amount IS NULL",
            array('0.000', '0.000')
        );
        $this->db->pquery(
            "UPDATE vtiger_purchaseorder SET p_open_amount=total, p_paid_amount=?,balance=total WHERE postatus!=? AND p_open_amount IS NULL AND p_paid_amount IS NULL",
            array('0.000', 'Cancelled')
        );
        $this->db->pquery(
            "UPDATE vtiger_salesorder SET p_open_amount=total, p_paid_amount=? WHERE sostatus!=? AND p_open_amount IS NULL AND p_paid_amount IS NULL",
            array('0.000', 'Cancelled')
        );
        $this->db->pquery("UPDATE vtiger_potential SET p_open_amount=amount, p_paid_amount=?", array('0.000'));

        if (Vtiger_Module::getInstance("ITS4YouPreInvoice") != false) {
            $this->db->pquery(
                "UPDATE its4you_preinvoice SET p_open_amount=total, p_paid_amount=? WHERE postatus!=? AND p_open_amount IS NULL AND p_paid_amount IS NULL",
                array('0.000', 'Cancelled')
            );
        }
        if (Vtiger_Module::getInstance("CreditNotes4You") != false) {
            $this->db->pquery(
                "UPDATE vtiger_creditnotes4you SET p_open_amount=total, p_paid_amount=? WHERE postatus!=? AND p_open_amount IS NULL AND p_paid_amount IS NULL",
                array('0.000', 'Cancelled')
            );
        }
    }
}
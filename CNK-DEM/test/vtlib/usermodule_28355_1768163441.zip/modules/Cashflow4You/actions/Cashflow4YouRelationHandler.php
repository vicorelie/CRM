<?php
/* * *******************************************************************************
 * The content of this file is subject to the Cashflow4You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

class Cashflow4YouRelationHandler extends VTEventHandler
{
    /**
     * @throws AppException
     * @params string $handlerType
     * @params object $entityData
     */
    public function handleEvent($handlerType, $entityData)
    {
        $entityId = $entityData->getId();
        $moduleName = $entityData->getModuleName();

        if (in_array($moduleName, ['Invoice', 'PurchaseOrder', 'SalesOrder'])) {
            $relationModel = new Cashflow4You_Relation_Model();
            $relationModel->updateSavedRelation($moduleName, $entityId);
        }
    }
}

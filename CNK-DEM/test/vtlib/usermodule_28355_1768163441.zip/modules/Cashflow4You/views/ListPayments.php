<?php
/* * *******************************************************************************
 * The content of this file is subject to the Cashflow 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

class Cashflow4You_ListPayments_View extends Vtiger_BasicAjax_View
{
    /**
     * @param Vtiger_Request $request
     * @throws Exception
     */
    public function process(Vtiger_Request $request)
    {
        $moduleName = $request->getModule();
        $mode = $request->getMode();
        $currentLanguage = Vtiger_Language_Handler::getLanguage();
        $recordId = $request->get('record');
        $adb = PearDatabase::getInstance();
        $utils = new Cashflow4You_Utils_Model();

        if (!$request->has('loadPayments')) {
            $request->set('loadPayments', '');
        }

        $relation_module = $request->get('source_module');

        if (empty($relation_module) && !empty($recordId)) {
            $relation_module = getSalesEntityType($recordId);
        }

        $integrationModel = Cashflow4You_Integration_Model::getInstance($relation_module);
        $moduleTable = $integrationModel->getModuleTable();
        $moduleTableId = $integrationModel->getModuleTableId();
        $moduleTotal = $integrationModel->getTotalFieldColumn();
        $isInventoryModule = $integrationModel->isInventoryModule();

        $viewer = $this->getViewer($request);
        $viewer->assign('RECORD', $recordId);
        $viewer->assign('RELATION_MODULE', $relation_module);
        $viewer->assign('LOAD_PAYMENTS', $request->get('loadPayments'));
        $viewer->assign('PAYTYPE', $request->get('paytype'));
        $viewer->assign('IS_INVENTORY_MODULE', $isInventoryModule);

        if ('loadPayments' !== $request->get('paytype')) {
            $Payments = array();
            $total = 0;
            $i = 1;
            $result = $adb->pquery($integrationModel->getPaymentsQuery(), array($recordId));

            while ($row = $adb->fetchByAssoc($result)) {
                $Payments[$row['cashflow4youid']] = array(
                    'no' => $i++,
                    'paymentstatus' => $row['cashflow4you_status'],
                    'paymentdate' => $row['paymentdate'] ? getValidDisplayDate($row['paymentdate']) : '',
                    'amount' => $utils->getCurrentUserNumberFormat($row['partial_amount'], $row['currency_symbol']),
                );
                $total += $row['partial_amount'];
            }

            $viewer->assign('PAYMENTS', $Payments);

            if ($isInventoryModule) {
                $sql = sprintf(
                    'SELECT %s.%s, vtiger_currency_info.currency_symbol 
                        FROM %s
                        INNER JOIN vtiger_crmentity ON vtiger_crmentity.crmid=%s.%s
                        INNER JOIN vtiger_currency_info ON vtiger_currency_info.id = %s.currency_id 
                        WHERE vtiger_crmentity.deleted=0 AND %s.%s=?',
                    $moduleTable,
                    $moduleTotal,
                    $moduleTable,
                    $moduleTable,
                    $moduleTableId,
                    $moduleTable,
                    $moduleTable,
                    $moduleTableId
                );
                $result = $adb->pquery($sql, array($recordId));
                $row = $adb->query_result_rowdata($result);
                $totalCurrencySymbol = $row['currency_symbol'];

                $grandTotal = $row[$moduleTotal];
                $totalBalance = $grandTotal - $total;

                $viewer->assign('TOTAL', $utils->getCurrentUserNumberFormat($total, $totalCurrencySymbol));
                $viewer->assign('TOTAL_CURRENCY', $totalCurrencySymbol);
                $viewer->assign('GRAND_TOTAL', $utils->getCurrentUserNumberFormat($grandTotal, $totalCurrencySymbol));
                $viewer->assign('TOTAL_BALLANCE', $utils->getCurrentUserNumberFormat($totalBalance, $totalCurrencySymbol));
            }
        }

        $viewer->assign('CASHFLOW4YOU_MOD', return_module_language($currentLanguage, $moduleName));
        $viewer->assign('MODULE', $moduleName);
        $viewer->assign('MODULE_MODEL', Vtiger_Module_Model::getInstance($moduleName));
        $viewer->assign('SOURCE_ID', $request->get('record'));
        $viewer->assign('SOURCE_MODULE', $request->get('source_module'));

        if ('Widget' === $mode) {
            $viewer->view('ListPaymentWidget.tpl', $moduleName);
        } else {
            $viewer->view('Cashflow4YouActions.tpl', $moduleName);
        }
    }
}
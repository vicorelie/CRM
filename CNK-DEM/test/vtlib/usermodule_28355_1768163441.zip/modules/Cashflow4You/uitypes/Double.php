<?php

class Cashflow4You_Double_UIType extends Vtiger_Double_UIType
{
    public function getDetailViewTemplateName()
    {
        if('paymentamount'=== $this->get('field')->get('name')) {
            return 'uitypes/PaymentAmountDetailView.tpl';
        }

        return parent::getDetailViewTemplateName();
    }

    /**
     * @param mixed $value
     * @param int $record
     * @param object $recordInstance
     * @return String
     */
    public function getDisplayValue($value, $record = false, $recordInstance = false)
    {
        return CurrencyField::convertToUserFormat((float)decimalFormat($value), null, true);
    }
}
<?php
/* * *******************************************************************************
 * The content of this file is subject to the Cashflow4You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

class Cashflow4You_Relation_Model extends Vtiger_Relation_Model
{
    const INVOICE = 'Invoice';
    const POTENTIALS = 'Potentials';
    const PURCHASE_ORDER = 'PurchaseOrder';
    const CREDIT_NOTES = 'CreditNotes4You';
    const CASHFLOW = 'Cashflow4You';
    public $db, $log, $column_fields;

    public function __construct()
    {
        global $log;

        $this->column_fields = getColumnFields('Cashflow4You');
        $this->db = PearDatabase::getInstance();
        $this->log = $log;
    }

    /**
     * @var int $record
     * @throws AppException
     */
    public function updateSavedRelations($record)
    {
        $result = $this->db->pquery('SELECT cashflow4you_associated_id 
                            FROM its4you_cashflow4you_associatedto 
                            INNER JOIN vtiger_crmentity ON vtiger_crmentity.crmid=its4you_cashflow4you_associatedto.cashflow4you_associated_id 
                            WHERE vtiger_crmentity.deleted=? AND its4you_cashflow4you_associatedto.cashflow4youid=?',
            array('0', $record));

        while ($row = $this->db->fetchByAssoc($result)) {
            $associatedId = $row['cashflow4you_associated_id'];
            $associatedModule = getSalesEntityType($associatedId);

            $this->updateSavedRelation($associatedModule, $associatedId, $record);
        }
    }

    /**
     * @throws AppException
     * @throws Exception
     */
    public function updateSavedRelation($module, $id, $cashflow4youId = 0)
    {
        if (empty($module) || empty($id) || !isRecordExists($id)) {
            return null;
        }

        $utils = new Cashflow4You_Utils_Model();
        $current_user = Users_Record_Model::getCurrentUserModel();
        $integrationModel = Cashflow4You_Integration_Model::getInstance($module);
        $relRecordModel = Vtiger_Record_Model::getInstanceById($id, $module);

        if (!$integrationModel->isActive()) {
            if (!empty($cashflow4youId)) {
                $result = $this->db->pquery('SELECT currency_id FROM its4you_cashflow4you WHERE cashflow4youid=? AND currency_id IS NOT NULL AND currency_id != ?', array($cashflow4youId, ''));

                if ($this->db->num_rows($result) == 0) {
                    Cashflow4You_Record_Model::updateRecord($cashflow4youId, ['currency_id' => $current_user->currency_id]);
                }
            }

            return null;
        }

        $numberField = $integrationModel->getNumberFieldColumn();
        $statusField = $integrationModel->get('status_field');
        $statusFieldColumn = $integrationModel->getStatusColumn();
        $statusValue = $integrationModel->get('status_value');
        $statusValueBack = $integrationModel->get('status_value_back');
        $relatedToField = $integrationModel->get('relatedto_field');
        $totalField = $integrationModel->get('total_field');

        if (!empty($cashflow4youId)) {
            Cashflow4You_Record_Model::updateRecord($cashflow4youId, [
                'relation_no' => $relRecordModel->get($numberField),
                'cashflow4you_associated_no' => $relRecordModel->get($numberField),
            ]);

            if (!empty($relatedToField)) {
                $this->db->pquery(
                    'UPDATE its4you_cashflow4you SET relatedto=? WHERE cashflow4youid=? AND relatedto=?',
                    array($relRecordModel->get($relatedToField), $cashflow4youId, '')
                );
            }
        }

        $paid = 0;
        $currency_rate = 1;
        $currency_id = 1;

        if (self::POTENTIALS !== $module) {
            $currencyRateAndSymbol = getCurrencySymbolandCRate($relRecordModel->get('currency_id'));
            $currency_rate = $currencyRateAndSymbol['rate'];
            $currency_id = $relRecordModel->get('currency_id');
        }

        $total = floatval($relRecordModel->get($totalField));
        $to_pay = abs($total);

        if (self::INVOICE === $module) {
            $this->setInvoiceAssociated($module, $id);
        } elseif (in_array($module, ['SalesOrder', 'ITS4YouPreInvoice']) && !empty($cashflow4youId)) {
            $query = 'SELECT cashflow4you_associated_id FROM its4you_cashflow4you_associatedto
                      INNER JOIN vtiger_crmentity on vtiger_crmentity.crmid=its4you_cashflow4you_associatedto.cashflow4youid 
                      INNER JOIN vtiger_invoice on vtiger_invoice.invoiceid=its4you_cashflow4you_associatedto.cashflow4you_associated_id 
                      WHERE vtiger_crmentity.deleted=0
                      AND vtiger_invoice.salesorderid=?
                      AND its4you_cashflow4you_associatedto.cashflow4youid=?';
            $result2 = $this->db->pquery($query, array($id, $cashflow4youId));

            if ($this->db->num_rows($result2) == 1) {
                $id = $this->db->query_result($result2, 0, 'cashflow4you_associated_id');
                $integrationModel = Cashflow4You_Integration_Model::getInstance('Invoice');
                $relRecordModel = Vtiger_Record_Model::getInstanceById($id, 'Invoice');
                $statusField = $integrationModel->get('status_field');
                $statusFieldColumn = $integrationModel->getStatusColumn();
                $statusValue = $integrationModel->get('status_value');
                $statusValueBack = $integrationModel->get('status_value_back');
            }
        }

        if (self::INVOICE === $module) {
            $query = 'SELECT its4you_cashflow4you_associatedto.cashflow4youid, partial_amount AS amount, its4you_cashflow4you.cashflow4you_paytype, its4you_cashflow4you.relationid, 
                its4you_cashflow4you.currency_id, its4you_cashflow4you.payamount_main 
                FROM its4you_cashflow4you_associatedto
                INNER JOIN vtiger_crmentity on vtiger_crmentity.crmid=its4you_cashflow4you_associatedto.cashflow4youid 
                INNER JOIN its4you_cashflow4you on its4you_cashflow4you.cashflow4youid=its4you_cashflow4you_associatedto.cashflow4youid 
                WHERE vtiger_crmentity.deleted=0
                AND its4you_cashflow4you.relationid IS NOT NULL
                AND its4you_cashflow4you_associatedto.cashflow4you_associated_id=?
                AND its4you_cashflow4you_associatedto.cashflow4youid IN (SELECT cashflow4youid FROM its4you_cashflow4you WHERE cashflow4you_status=? OR cashflow4you_status=?)
                GROUP BY its4you_cashflow4you_associatedto.cashflow4youid';
        } elseif (self::POTENTIALS === $module) {
            $query = 'SELECT payamount_main AS amount, cashflow4you_paytype, relationid
                FROM its4you_cashflow4you 
                INNER JOIN vtiger_crmentity on vtiger_crmentity.crmid=its4you_cashflow4you.cashflow4youid 
                WHERE vtiger_crmentity.deleted=0 
                AND its4you_cashflow4you.relationid=?
                AND its4you_cashflow4you.cashflow4youid IN (SELECT cashflow4youid FROM its4you_cashflow4you WHERE cashflow4you_status=? OR cashflow4you_status=?) 
                GROUP BY its4you_cashflow4you.cashflow4youid';
        } else {
            $query = 'SELECT paymentamount AS amount, cashflow4you_paytype, relationid, currency_id, payamount_main
                FROM its4you_cashflow4you 
                INNER JOIN vtiger_crmentity on vtiger_crmentity.crmid=its4you_cashflow4you.cashflow4youid 
                WHERE vtiger_crmentity.deleted=0 
                AND its4you_cashflow4you.relationid=?
                AND its4you_cashflow4you.cashflow4youid IN (SELECT cashflow4youid FROM its4you_cashflow4you WHERE cashflow4you_status=? OR cashflow4you_status=?) 
                GROUP BY its4you_cashflow4you.cashflow4youid';
        }

        $result2 = $this->db->pquery($query, array($id, 'Paid', 'Received'));
        $num = $this->db->num_rows($result2);

        if ($num > 0) {
            $sumPaymentAmount = 0;

            while ($row = $this->db->fetchByAssoc($result2)) {
                if (self::INVOICE === $module) {
                    $this->updateRelationsField($row['cashflow4youid']);
                }

                $currencyId = $row['currency_id'];

                $amount = abs($row['amount']);

                if ($currencyId != $currency_id) {
                    $amount = CurrencyField::convertFromMasterCurrency($amount, $currency_rate);
                }

                if ('Incoming' === $row['cashflow4you_paytype']) {
                    $sumPaymentAmount += $amount;
                } else {
                    $sumPaymentAmount -= $amount;
                }
            }

            if (in_array(getSalesEntityType($id), ['PurchaseOrder', 'CreditNotes4You'])) {
                $sumPaymentAmount *= -1;
            }

            $paid = $utils->defaultNumberFormat($sumPaymentAmount);
            $to_pay = $utils->defaultNumberFormat($to_pay - $paid);

            if ($to_pay < 0) {
                $to_pay = 0;
            }
        }

        Cashflow4You_Module_Model::updatePaymentValues($to_pay, $paid, $relRecordModel);

        $updateStatus = $this->getUpdateStatus($module);

        $paid = number_format($paid, $current_user->no_of_currency_decimals, '.', '');
        $total = number_format($total, $current_user->no_of_currency_decimals, '.', '');
        $to_pay = number_format($to_pay, $current_user->no_of_currency_decimals, '.', '');

        if (!empty($cashflow4youId) || $updateStatus == 1) {
            if (!empty($statusField) && !empty($statusValue)) {
                if ($paid >= $total && $to_pay == 0) {
                    Cashflow4You_Module_Model::updateRecordStatus($relRecordModel, $statusField, $statusValue);

                    if (self::CREDIT_NOTES === $module && 'Refunded' === $statusValue && class_exists('CreditNotes4You_ProductsUpdate_Helper')) {
                        CreditNotes4You_ProductsUpdate_Helper::updateInventoryProductsByStatus($id, $statusValue);
                    }
                } else {
                    if ($relRecordModel->get($statusField) === $statusValue) {
                        Cashflow4You_Module_Model::updateRecordStatus($relRecordModel, $statusField, $statusValueBack);
                    }
                }
            }
        }
    }

    private function setInvoiceAssociated($module, $id)
    {
        $so_query = 'SELECT vtiger_invoice.salesorderid, its4you_cashflow4you.cashflow4youid, its4you_cashflow4you.paymentamount, its4you_cashflow4you.payamount_main
                    FROM vtiger_invoice 
                    INNER JOIN vtiger_crmentity ON vtiger_crmentity.crmid=vtiger_invoice.invoiceid 
                    INNER JOIN its4you_cashflow4you ON its4you_cashflow4you.relationid=vtiger_invoice.salesorderid
                    WHERE vtiger_crmentity.deleted=0
                    AND vtiger_invoice.invoiceid=?';
        $resultSO = $this->db->pquery($so_query, array($id));
        $num = $this->db->num_rows($resultSO);

        if ($num > 0) {
            for ($i = 0; $i < $num; $i++) {
                $salesOrderId = $this->db->query_result($resultSO, $i, 'salesorderid');
                $cashFlowId = $this->db->query_result($resultSO, $i, 'cashflow4youid');
                $paymentAmount = $this->db->query_result($resultSO, $i, 'paymentamount');
                $query = 'SELECT partial_amount 
                      FROM its4you_cashflow4you_associatedto
                      INNER JOIN vtiger_crmentity on vtiger_crmentity.crmid=its4you_cashflow4you_associatedto.cashflow4youid 
                      WHERE vtiger_crmentity.deleted=0
                      AND its4you_cashflow4you_associatedto.cashflow4you_associated_id=?
                      OR its4you_cashflow4you_associatedto.cashflow4youid=?
                      GROUP BY its4you_cashflow4you_associatedto.cashflow4youid';
                $result_rel = $this->db->pquery($query, array($salesOrderId, $cashFlowId));
                $num_rel = $this->db->num_rows($result_rel);

                if ($num_rel == 0) {
                    $this->saveAssociatedTo($cashFlowId, $id, $paymentAmount);
                    $this->saveRelation('Cashflow4You', $cashFlowId, 'Invoice', $id);
                }
            }
        }

        if (vtlib_isModuleActive('ITS4YouPreInvoice')) {
            $result = $this->db->pquery('SELECT presence FROM vtiger_tab WHERE name=?', array('ITS4YouPreInvoice'));
            $presence = $this->db->query_result($result, 0, 'presence');

            if ($presence == 0) {
                $query = 'SELECT cashflow4youid, paymentamount, its4you_cashflow4you.relationid
                        FROM  its4you_cashflow4you
                        INNER JOIN vtiger_crmentity on vtiger_crmentity.crmid=its4you_cashflow4you.cashflow4youid 
                        INNER JOIN its4you_preinvoice ON its4you_preinvoice.preinvoiceid=its4you_cashflow4you.relationid
                        WHERE vtiger_crmentity.deleted=0
                        AND  its4you_preinvoice.rel_invoiceid=?';
                $result = $this->db->pquery($query, array($id));
                $num = $this->db->num_rows($result);

                if ($num > 0) {
                    for ($i = 0; $i < $num; $i++) {
                        $cashFlowId = $this->db->query_result($result, $i, 'cashflow4youid');
                        $paymentAmount = $this->db->query_result($result, $i, 'paymentamount');
                        $relationId = $this->db->query_result($result, $i, 'relationid');
                        $query = 'SELECT partial_amount 
                                FROM its4you_cashflow4you_associatedto
                                INNER JOIN vtiger_crmentity on vtiger_crmentity.crmid=its4you_cashflow4you_associatedto.cashflow4youid 
                                WHERE vtiger_crmentity.deleted=0
                                AND its4you_cashflow4you_associatedto.cashflow4you_associated_id=?
                                AND its4you_cashflow4you_associatedto.cashflow4youid=?';
                        $result_rel = $this->db->pquery($query, array($id, $cashFlowId));
                        $num_rel = $this->db->num_rows($result_rel);

                        if ($num_rel == 0) {
                            $this->saveAssociatedTo($cashFlowId, $id, $paymentAmount);
                            $this->saveRelation('Cashflow4You', $cashFlowId, 'Invoice', $id);
                        }
                    }
                }
            }
        }
    }

    /**
     * @param int $cashFlowId
     * @param int $record
     * @param float $amount
     */
    public function saveAssociatedTo($cashFlowId, $record, $amount)
    {
        $this->db->pquery('INSERT INTO its4you_cashflow4you_associatedto ( cashflow4youid, cashflow4you_associated_id, partial_amount )VALUES (?, ?, ?)',
            array($cashFlowId, $record, $amount)
        );
    }

    /**
     * @param int $cashFlowId
     * @param int $record
     * @param float $amount
     */
    public function updateAssociatedTo($cashFlowId, $record, $amount)
    {
        $this->db->pquery('UPDATE its4you_cashflow4you_associatedto SET partial_amount = ? WHERE  cashflow4you_associated_id=? AND cashflow4youid=?',
            array($amount, $record, $cashFlowId)
        );
    }

    public function updateCashFlowAssociatedTo($record, $values)
    {
        $this->db->pquery('UPDATE its4you_cashflow4you_associatedto SET ' . implode('=?,', array_keys($values)) . '=? WHERE cashflow4youid=?',
            array($values, $record)
        );
    }

    /**
     * @param string $module
     * @param int $record
     * @param string $relationModule
     * @param int $relationRecord
     */
    public function saveRelation($module, $record, $relationModule, $relationRecord)
    {
        $this->db->pquery(
            'INSERT INTO vtiger_crmentityrel ( crmid, module, relcrmid, relmodule )VALUES (?, ?, ?, ?)',
            array($record, $module, $relationRecord, $relationModule)
        );
    }

    /**
     * @param int $recordId
     * @throws Exception
     */
    public function updateRelationsField($recordId)
    {
        $relationInfo = array();

        $query = 'SELECT its4you_cashflow4you.relationid, vtiger_crmentity.setype 
            FROM its4you_cashflow4you 
            INNER JOIN vtiger_crmentity on vtiger_crmentity.crmid=its4you_cashflow4you.relationid
            WHERE cashflow4youid=? AND relationid != 0';
        $result = $this->db->pquery($query, array($recordId));

        while ($row = $this->db->fetchByAssoc($result)) {
            $relationInfo[$row['relationid']] = $row['setype'];
        }

        $query = 'SELECT its4you_cashflow4you_associatedto.cashflow4you_associated_id,vtiger_crmentity.setype 
            FROM its4you_cashflow4you_associatedto
            INNER JOIN vtiger_crmentity on vtiger_crmentity.crmid=its4you_cashflow4you_associatedto.cashflow4you_associated_id
            WHERE cashflow4youid=?';
        $result = $this->db->pquery($query, [$recordId]);

        while ($row = $this->db->fetchByAssoc($result)) {
            $relationInfo[$row['cashflow4you_associated_id']] = $row['setype'];
        }

        $relations = array();

        foreach ($relationInfo as $id => $module) {
            $integrationModel = Cashflow4You_Integration_Model::getInstance($module);
            $numberFieldColumn = $integrationModel->getNumberFieldColumn();

            if (empty($numberFieldColumn)) {
                throw new AppException(sprintf('Missing Numbering field for module: %s', $module));
            }

            $query = sprintf('SELECT %s AS no FROM %s WHERE %s=?', $numberFieldColumn, $integrationModel->getModuleTable(), $integrationModel->getModuleTableId());
            $result = $this->db->pquery($query, array($id));

            array_push($relations, $this->db->query_result($result, 0, 'no'));
        }

        Cashflow4You_Record_Model::updateRecord($recordId, [
            'relations' => implode(' ', $relations),
        ]);
    }

    public function getUpdateStatus($module)
    {
        $updateStatus = 0;
        $referenceString = $_REQUEST['refstring'];

        if (vtlib_isModuleActive('ITS4YouPreInvoice') && self::INVOICE === $module && !empty($referenceString)) {
            $listIds = explode(';', $referenceString);
            $isITS4YouPreInvoice = false;

            foreach ($listIds as $listId) {
                if ('ITS4YouPreInvoice' === getSalesEntityType($listId)) {
                    $isITS4YouPreInvoice = true;
                }
            }

            if ($isITS4YouPreInvoice) {
                $updateStatus = 1;
            }
        }

        return $updateStatus;
    }

    function QuickCashflow4YouCreate($DefaultValue)
    {
        $module = "Cashflow4You";

        $this->log->debug("Entering QuickCreate(" . $module . ") method ...");
        $current_user = Users_Record_Model::getCurrentUserModel();

        $tabid = getTabid($module);
        $is_admin = false;
        $profileGlobalPermission = array();

        require('user_privileges/user_privileges_' . $current_user->id . '.php');
        if ($is_admin == true || $profileGlobalPermission[1] == 0 || $profileGlobalPermission[2] == 0) {
            $quickcreate_query = "select * from vtiger_field where quickcreate in (0,2) and tabid = ? and vtiger_field.presence in (0,2) and displaytype != 2 order by sequence";
            $params = [$tabid];
        } else {
            $profileList = getCurrentUserProfileList();
            $quickcreate_query = "SELECT vtiger_field.* FROM vtiger_field INNER JOIN vtiger_profile2field ON vtiger_profile2field.fieldid=vtiger_field.fieldid INNER JOIN vtiger_def_org_field ON vtiger_def_org_field.fieldid=vtiger_field.fieldid WHERE vtiger_field.tabid=? AND quickcreate in (0,2) AND vtiger_profile2field.visible=0 AND vtiger_profile2field.readonly = 0 AND vtiger_def_org_field.visible=0  AND vtiger_profile2field.profileid IN (" . generateQuestionMarks($profileList) . ") and vtiger_field.presence in (0,2) and displaytype != 2 GROUP BY vtiger_field.fieldid ORDER BY sequence";
            $params = [$tabid, $profileList];
            //Postgres 8 fixes
            if ($this->db->dbType == "pgsql") {
                $quickcreate_query = fixPostgresQuery($quickcreate_query, $this->log, 0);
            }
        }
        $category = getParentTab();
        $result = $this->db->pquery($quickcreate_query, $params);
        $noofrows = $this->db->num_rows($result);
        $fieldName_array = array();
        for ($i = 0; $i < $noofrows; $i++) {
            $fieldtablename = $this->db->query_result($result, $i, 'tablename');
            $uitype = $this->db->query_result($result, $i, "uitype");
            $fieldname = $this->db->query_result($result, $i, "fieldname");
            $fieldlabel = $this->db->query_result($result, $i, "fieldlabel");
            $maxlength = $this->db->query_result($result, $i, "maximumlength");
            $generatedtype = $this->db->query_result($result, $i, "generatedtype");
            $typeofdata = $this->db->query_result($result, $i, "typeofdata");
            $defaultvalue = $this->db->query_result($result, $i, "defaultvalue");
            if (array_key_exists($fieldlabel, $DefaultValue)) {
                $defaultvalue = $DefaultValue[$fieldlabel];
            }
            $col_fields[$fieldname] = $defaultvalue;

            //to get validationdata
            $fldLabel_array = array();
            $fldLabel_array[getTranslatedString($fieldlabel)] = $typeofdata;
            $fieldName_array[$fieldname] = $fldLabel_array;

            // These fields should not be shown in the UI as they are already shown as part of other fields, but are required for validation.
            if ($fieldname == 'time_start' || $fieldname == 'time_end') {
                continue;
            }

            $custfld = getOutputHtml($uitype, $fieldname, $fieldlabel, $maxlength, $col_fields, $generatedtype, $module,
                '', $typeofdata);
            $qcreate_arr[] = $custfld;
        }
        for ($i = 0, $j = 0; $i < count($qcreate_arr); $i = $i + 2, $j++) {
            $key1 = $qcreate_arr[$i];
            if (is_array($qcreate_arr[$i + 1])) {
                $key2 = $qcreate_arr[$i + 1];
            } else {
                $key2 = array();
            }
            $return_data[$j] = [0 => $key1, 1 => $key2];
        }
        $form_data['form'] = $return_data;
        $form_data['data'] = $fieldName_array;
        $this->log->debug("Exiting QuickCreate method ..." . print_r($form_data, true));

        return $form_data;
    }

    function updateRelations($destination_module, $destination_id, $entityid)
    {
        require_once('include/database/PearDatabase.php');
        include_once('user_privileges/default_module_view.php');

        global $singlepane_view, $currentModule;
        $idlist = vtlib_purify($_REQUEST['idstring']);
        $destinationModule = vtlib_purify($destination_module);
        $parenttab = getParentTab();

        $forCRMRecord = vtlib_purify($destination_id);
        $mode = $_REQUEST['mode'];

        $focus = CRMEntity::getInstance("Cashflow4You");

        if ($mode == 'delete') {
            // Split the string of ids
            if (empty($_REQUEST['idstring'])) {
                $currentModule = $destinationModule;
                $destinationModule = 'Cashflow4You';
            }
            $ids = explode(";", $idlist);
            if (!empty($ids)) {
                $focus->delete_related_module($currentModule, $forCRMRecord, $destinationModule, $ids);
            }
        } else {
            if (!empty($_REQUEST['idstring'])) {
                // Split the string of ids
                $ids = explode(";", trim($idlist, ";"));
            } elseif (!empty($entityid)) {
                $ids = $entityid;
            }

            if (!empty($ids)) {
                $focus->save_related_module("Cashflow4You", $forCRMRecord, $destinationModule, $ids);
            }
        }
    }

    /**
     * @throws AppException
     * @throws Exception
     */
    function SavePaymentFromRelation()
    {
        $_REQUEST['ajxaction'] = 'DETAILVIEW';

        if (!isset($_REQUEST['sourcemodule']) || empty($_REQUEST['sourcemodule'])) {
            header('Location: ' . $_SERVER['HTTP_REFERER']);
            exit;
        }

        $utils = new Cashflow4You_Utils_Model();
        $module = $_REQUEST['sourcemodule'];
        $integrationModel = Cashflow4You_Integration_Model::getInstance($module);
        $statusField = $integrationModel->getStatusColumn();
        $statusFieldName = $integrationModel->get('status_field');
        $statusValue = $integrationModel->get('status_value');
        $statusValueBack = $integrationModel->get('status_value_back');
        $totalField = $integrationModel->get('total_field');

        $idString = vtlib_purify($_REQUEST['idstring']);
        $idString = trim($idString, ';');
        $listIds = explode(';', $idString);

        foreach ($listIds as $invoiceId) {
            $invoiceRecord = Vtiger_Record_Model::getInstanceById($invoiceId, $module);
            $openAmount = $invoiceRecord->get('openamount');
            $paidAmount = $invoiceRecord->get('paidamount');
            $toPay = $invoiceRecord->get($totalField);

            $query = 'SELECT cashflow4youid, partial_amount AS amount 
                FROM its4you_cashflow4you_associatedto
                INNER JOIN vtiger_crmentity on vtiger_crmentity.crmid=its4you_cashflow4you_associatedto.cashflow4youid 
                WHERE vtiger_crmentity.deleted=0 
                  AND its4you_cashflow4you_associatedto.cashflow4you_associated_id=? 
                  AND its4you_cashflow4you_associatedto.cashflow4youid IN (SELECT cashflow4youid FROM its4you_cashflow4you WHERE cashflow4you_status = ? OR cashflow4you_status = ?)
                GROUP BY its4you_cashflow4you_associatedto.cashflow4youid';
            $result = $this->db->pquery($query, array($invoiceId, 'Paid', 'Received'));
            $num = $this->db->num_rows($result);

            if ($num > 0) {
                $sumPaymentAmount = 0;

                while($row = $this->db->fetchByAssoc($result)) {
                    $sumPaymentAmount += $row['amount'];
                }

                $paidAmount = $utils->defaultNumberFormat($sumPaymentAmount);
                $openAmount = $utils->defaultNumberFormat($toPay - $paidAmount);

                if ($openAmount < 0) {
                    $openAmount = 0;
                }
            }

            Cashflow4You_Module_Model::updatePaymentValues($openAmount, $paidAmount, $invoiceRecord);

            if (self::INVOICE === $module && !empty($statusField) && !empty($statusValue)) {
                if ($openAmount <= 0) {
                    Cashflow4You_Module_Model::updateRecordStatus($invoiceRecord, $statusFieldName, $statusValue);
                } elseif ($invoiceRecord->get($statusFieldName) === $statusValue) {
                    Cashflow4You_Module_Model::updateRecordStatus($invoiceRecord, $statusFieldName, $statusValueBack);
                }
            }
        }
    }

    /**
     * @param int $record
     * @return int
     * @throws Exception
     */
    public function countAssociatedTo($record)
    {
        $select = 'SELECT COUNT(*) AS count 
            FROM its4you_cashflow4you_associatedto 
            INNER JOIN vtiger_crmentity ON vtiger_crmentity.crmid=its4you_cashflow4you_associatedto.cashflow4you_associated_id 
            WHERE vtiger_crmentity.deleted=0 AND its4you_cashflow4you_associatedto.cashflow4youid=?';
        $selectResult = $this->db->pquery($select, array($record));

        return intval($this->db->query_result($selectResult, 0, 'count'));
    }
}
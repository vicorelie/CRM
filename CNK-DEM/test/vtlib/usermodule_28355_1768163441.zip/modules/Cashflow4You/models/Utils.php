<?php
/* * *******************************************************************************
 * The content of this file is subject to the Cashflow4You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */
const GREEN = "#009900";
const RED = "#FF0000";

class Cashflow4You_Utils_Model extends Vtiger_Base_Model
{
    public $current_user;
    public $db;

    public $Entity_table = array(
        "Invoice" => array(
            "entity" => "invoice",
            "table" => "vtiger_invoice",
            "status" => "invoicestatus",
            "status_value" => "Paid",
            "status_value_back" => "Created",
            "relatedto" => "accountid",
            "total_fld" => "total"
        ),
        "PurchaseOrder" => array(
            "entity" => "purchaseorder",
            "table" => "vtiger_purchaseorder",
            "status" => "postatus",
            "status_value" => "",
            "status_value_back" => "",
            "relatedto" => "vendorid",
            "total_fld" => "total"
        ),
        "SalesOrder" => array(
            "entity" => "salesorder",
            "table" => "vtiger_salesorder",
            "status" => "sostatus",
            "status_value" => "",
            "status_value_back" => "",
            "relatedto" => "accountid",
            "total_fld" => "total"
        ),
        "Potentials" => array(
            "entity" => "potential",
            "table" => "vtiger_potential",
            "status" => "sales_stage",
            "status_value" => "",
            "status_value_back" => "",
            "relatedto" => "related_to",
            "total_fld" => "amount"
        ),
        "CreditNotes4You" => array(
            "entity" => "creditnotes4you",
            "table" => "vtiger_creditnotes4you",
            "status" => "creditnotes4youstatus",
            "status_value" => "Refunded",
            "status_value_back" => "Created",
            "relatedto" => "accountid",
            "total_fld" => "total"
        ),
        "ITS4YouPreInvoice" => array(
            "entity" => "preinvoice",
            "table" => "its4you_preinvoice",
            "status" => "preinvoicestatus",
            "status_value" => "Paid",
            "status_value_back" => "Created",
            "relatedto" => "accountid",
            "total_fld" => "total"
        ),
    );

    public function __construct($values = array())
    {
        parent::__construct($values);
        $this->current_user = Users_Record_Model::getCurrentUserModel();
        $this->db = PearDatabase::getInstance();
    }

    /**
     * @param string $column
     * @param string $table
     * @return int
     * @throws Exception
     */
    public static function getUiType($column, $table)
    {
        $adb = PearDatabase::getInstance();
        $result = $adb->pquery('SELECT uitype FROM vtiger_field WHERE columnname LIKE ? AND tablename LIKE ?', array('paymentamount', 'its4you_cashflow4you'));

        return intval($adb->query_result($result, 0, 'uitype'));
    }

    /**
     * @param object $recordModel
     * @return float
     */
    public static function calculateVatAmount($recordModel)
    {
        if (!method_exists($recordModel, 'getProducts')) {
            return 0;
        }

        $relatedProducts = $recordModel->getProducts();
        $amount = 0;

        foreach ($relatedProducts[1]['final_details']['taxes'] as $tax) {
            $amount += floatval($tax['amount']);
        }

        return floatval($amount);
    }

    public function formatNumber($number, $groupSeparator = true)
    {
        $decimalSep = $this->current_user->column_fields['currency_decimal_separator'];
        $groupSep = $this->current_user->column_fields['currency_grouping_separator'];
        $number = $number * 1;

        if ($groupSeparator) {
            return number_format($number, getCurrencyDecimalPlaces(), $decimalSep, $groupSep);
        }

        return number_format($number, getCurrencyDecimalPlaces(), $decimalSep, '');
    }

    public function getUserDateFormat()
    {
        return $this->current_user->column_fields["date_format"];
    }

    /**
     * @param int $crmId
     * @return string
     * @throws Exception
     */
    public function getModuleById($crmId)
    {
        $result = $this->db->pquery('SELECT setype FROM vtiger_crmentity WHERE crmid=?', array($crmId));

        return $this->db->query_result($result, 0, 'setype');
    }

    public function getColor($color = 'green')
    {
        if ('green' === $color) {
            return GREEN;
        }

        if ('red' === $color) {
            return RED;
        }

        return null;
    }

    /**
     * @param string|int|float $value
     * @return float
     */
    public function defaultNumberFormat($value)
    {
        return floatval(number_format($value, 3, '.', ''));
    }

    /**
     * @param string $amount
     * @param string $symbol
     * @return string
     */
    public function getCurrentUserNumberFormat($amount, $symbol)
    {
        global $current_user;

        return CurrencyField::appendCurrencySymbol(
            CurrencyField::convertToUserFormat($amount, $current_user, true),
            $symbol
        );
    }

    public static function formatInvoicesValues(&$invoices, $invoiceId, $currencySymbol)
    {
        $currentUser = Users_Record_Model::getCurrentUserModel();

        foreach ($invoices[$invoiceId] as $fieldColumn => $fieldValue) {
            if (!in_array($fieldColumn, ['subject', 'invoice_no'])) {
                $invoices[$invoiceId][$fieldColumn . '_hidden'] = $fieldValue;
                $fieldValue = CurrencyField::convertToUserFormat($fieldValue, $currentUser, true);

                if ($fieldColumn !== 'openamount') {
                    $fieldValue = CurrencyField::appendCurrencySymbol($fieldValue, $currencySymbol);
                }

                $invoices[$invoiceId][$fieldColumn] = $fieldValue;
            }
        }
    }
}
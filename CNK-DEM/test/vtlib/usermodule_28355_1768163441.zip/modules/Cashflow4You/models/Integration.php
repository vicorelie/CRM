<?php
/* * *******************************************************************************
 * The content of this file is subject to the Cashflow 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

class Cashflow4You_Integration_Model extends Vtiger_Base_Model
{
    const SALES_ORDER = 'SalesOrder';
    const BLOCK_LABEL = 'Cashflow Information';
    const RELATED_LIST_LABEL = 'Cashflow4You';
    public $block;
    public $fields;
    protected $adb;
    protected $module;
    protected $allowedModules = array(
        'Potentials',
    );

    protected $restrictedModules = array(
        'ITS4YouIssuecards',
        'ITS4YouWarehouseTransfers',
        'ITS4YouWHDeliveryNotes',
    );

    protected $defaults = array(
        'Invoice' => array(
            'status_field' => 'invoicestatus',
            'status_value' => 'Paid',
            'status_value_back' => 'Created',
            'relatedto_field' => 'account_id',
            'total_field' => 'hdnGrandTotal',
        ),
        'PurchaseOrder' => array(
            'status_field' => 'postatus',
            'relatedto_field' => 'vendor_id',
            'total_field' => 'hdnGrandTotal',
        ),
        'SalesOrder' => array(
            'status_field' => 'sostatus',
            'relatedto_field' => 'account_id',
            'total_field' => 'hdnGrandTotal',
        ),
        'Potentials' => array(
            'status_field' => 'sales_stage',
            'relatedto_field' => 'related_to',
            'total_field' => 'amount',
        ),
        'CreditNotes4You' => array(
            'status_field' => 'creditnotes4youstatus',
            'status_value' => 'Refunded',
            'status_value_back' => 'Created',
            'relatedto_field' => 'account_id',
            'total_field' => 'hdnGrandTotal',
        ),
        'ITS4YouPreInvoice' => array(
            'status_field' => 'preinvoicestatus',
            'status_value' => 'Paid',
            'status_value_back' => 'Created',
            'relatedto_field' => 'account_id',
            'total_field' => 'hdnGrandTotal',
        ),
    );

    public function __construct($values = array())
    {
        parent::__construct($values);

        $this->adb = PearDatabase::getInstance();
    }

    /**
     * @param Vtiger_Request $request
     * @throws Exception
     */
    public static function updateFromRequest($request)
    {
        $integration = $request->get('integration');
        $availableModules = self::getAvailableModules();

        /** @var self $availableModule */
        foreach ($availableModules as $availableModule) {
            $name = $availableModule->getModuleName();
            $moduleIntegration = $integration[$name];

            $availableModule->set('status_field', $moduleIntegration['status_field']);
            $availableModule->set('status_value', $moduleIntegration['status_value']);
            $availableModule->set('status_value_back', $moduleIntegration['status_value_back']);
            $availableModule->set('relatedto_field', $moduleIntegration['relatedto_field']);
            $availableModule->set('total_field', $moduleIntegration['total_field']);

            if (isset($moduleIntegration['active']) && 'yes' === $moduleIntegration['active']) {
                $availableModule->set('active', 'yes');
            } else {
                $availableModule->set('active', 'no');
            }

            $availableModule->save();

            if ($availableModule->isActive()) {
                $availableModule->updateSettings();
            } else {
                $availableModule->updateSettings(false);
            }
        }
    }

    /**
     * @throws Exception
     */
    public static function updateAvailableModules($register = true)
    {
        $availableModules = self::getAvailableModules();

        /** @var self $availableModule */
        foreach ($availableModules as $availableModule) {
            if ($availableModule->isActive()) {
                $availableModule->updateSettings($register);
            } else {
                $availableModule->updateSettings(false);
            }
        }
    }

    /**
     * @return array
     * @throws Exception
     */
    public static function getAvailableModules()
    {
        $modules = Vtiger_Module_Model::getEntityModules();
        $inventoryModules = array();

        foreach ($modules as $module) {
            $moduleIntegration = self::getInstance($module);

            if ($moduleIntegration->isAllowedModule()) {
                $inventoryModules[$module->getName()] = $moduleIntegration;
            }
        }

        return $inventoryModules;
    }

    /**
     * @param string|object $module
     * @return self
     * @throws Exception
     */
    public static function getInstance($module)
    {
        $self = new self();

        if (is_string($module)) {
            $moduleName = $module;
            $module = Vtiger_Module_Model::getInstance($module);
        } else {
            $moduleName = $module->getName();
        }

        $self->module = $module;
        $self->set('module', $moduleName);
        $self->retrieveInfo();

        return $self;
    }

    /**
     * @throws Exception
     */
    public function retrieveInfo()
    {
        $moduleName = $this->getModuleName();
        $result = $this->adb->pquery('SELECT * FROM its4you_cashflow4you_integration WHERE module=?', [$moduleName]);
        $values = $this->adb->query_result_rowdata($result);

        if (!empty($values)) {
            foreach ($values as $key => $value) {
                $this->set($key, $value);
            }
        }

        if ($this->isEmpty('id')) {
            if(isset($this->defaults[$moduleName])) {
                foreach ($this->defaults[$moduleName] as $key => $value) {
                    $this->set($key, $value);
                }

                $this->set('active', 'yes');
            }
        }
    }

    /**
     * @return string
     */
    public function getModuleName()
    {
        return (string)$this->get('module');
    }

    public function isActiveLink()
    {
        $sql = 'SELECT name FROM vtiger_tab INNER JOIN vtiger_links ON vtiger_links.tabid=vtiger_tab.tabid WHERE linkurl LIKE ? AND linktype != ? AND vtiger_tab.tabid=?';
        $result = $this->adb->pquery($sql, ['%cashflow4you%', 'HEADERSCRIPT', $this->getModule()->getId()]);

        return boolval($this->adb->num_rows($result));
    }

    /**
     * @return Vtiger_Module_Model
     */
    public function getModule()
    {
        return $this->module;
    }
    
    /**
     * @return Vtiger_Module
     */
    public function getModuleInstance()
    {
        return Vtiger_Module::getInstance($this->getModule()->getName());
    }

    public function isAllowedModule()
    {
        $module = $this->getModuleName();

        if (in_array($module, $this->restrictedModules)) {
            return false;
        }

        if (in_array($module, $this->allowedModules)) {
            return true;
        }

        return $this->isInventoryModule();
    }

    /**
     * @return bool
     */
    public function isInventoryModule()
    {
        return is_subclass_of($this->getModule(), 'Inventory_Module_Model');
    }

    public function save()
    {
        $params = array(
            'module' => $this->getModuleName(),
            'active' => $this->get('active'),
            'status_field' => $this->get('status_field'),
            'status_value' => $this->get('status_value'),
            'status_value_back' => $this->get('status_value_back'),
            'relatedto_field' => $this->get('relatedto_field'),
            'total_field' => $this->get('total_field'),
        );

        if (!$this->isEmpty('id')) {
            $sql = sprintf('UPDATE its4you_cashflow4you_integration SET %s=? WHERE id=?', implode('=?, ', array_keys($params)));
            $params['id'] = $this->get('id');
        } else {
            $sql = sprintf('INSERT INTO its4you_cashflow4you_integration (%s) VALUES (%s)', implode(',', array_keys($params)), generateQuestionMarks($params));
        }

        $this->adb->pquery($sql, $params);
        $id = $this->adb->getLastInsertID();

        if ($id) {
            $this->set('id', $id);
        }
    }

    public function isActive()
    {
        return 'yes' == $this->get('active');
    }

    public function updateSettings($register = true)
    {
        $this->updateRelationModule($register);
        $this->updateBlock($register);
        $this->updateFields($register);
        $this->updateRelatedLists($register);
        $this->updateLinks($register);
    }

    public function updateRelationModule($register = true)
    {
        $field = $this->getRelationField();
        $moduleNames = [$this->getModuleName()];

        if ($field) {
            $field->unsetRelatedModules($moduleNames);

            if ($register) {
                $field->setRelatedModules($moduleNames);
            }
        }
    }

    /**
     * @return false|Vtiger_Field_Model
     */
    public function getRelationField()
    {
        $moduleName = $this->getModuleName();
        $moduleInstance = $this->getCashFlow();

        if (in_array($moduleName, ['Accounts', 'Vendors'])) {
            return Vtiger_Field_Model::getInstance('relatedto', $moduleInstance);
        }

        return Vtiger_Field_Model::getInstance('relationid', $moduleInstance);
    }

    /**
     * @param bool $register
     */
    public function updateBlock($register = true)
    {
        $this->deleteCashFlowBlock();

        if ($register) {
            $this->addCashFlowBlock();
        }
    }

    /**
     * @param bool $register
     */
    public function updateFields($register = true)
    {
        $fields = array(
            'paidamount' => ['column' => 'p_paid_amount', 'label' => 'Paid Amount', 'presence' => 2],
            'openamount' => ['column' => 'p_open_amount', 'label' => 'Remaining Amount', 'presence' => 2],
        );

        foreach ($fields as $fieldName => $fieldData) {
            $this->deleteCashFlowField($fieldName);

            if ($register) {
                $this->addCashFlowField($fieldName, $fieldData);
                $this->addCashFlowColumn($this->getCashflowField($fieldName));
            }
        }
    }

    /**
     * @param object $field
     */
    public function addCashFlowColumn($field)
    {
        if (!columnExists($field->column, $field->table)) {
            $this->adb->query(sprintf('ALTER TABLE %s ADD %s DECIMAL(25, 8) NOT NULL', $field->table, $field->column));
        }
    }

    /**
     * @param string $name
     */
    public function deleteCashFlowField($name)
    {
        $this->adb->pquery('DELETE FROM vtiger_field WHERE fieldname=? AND tabid=?', array($name, $this->getModule()->getId()));
    }

    /**
     * @return bool
     */
    public function hasDuplicateField()
    {
        $result = $this->adb->pquery('SELECT fieldid FROM vtiger_field WHERE (fieldname=? OR fieldname=?) AND tabid=?', array('paidamount', 'openamount', $this->getModule()->getId()));

        return 2 < $this->adb->num_rows($result);
    }

    /**
     * @param string $name
     * @param array $data
     */
    public function addCashFlowField($name, $data)
    {
        $field = new Vtiger_Field_Model();
        $field->set('name', $name);
        $field->set('table', $this->getModuleTable());
        $field->set('columntype', 'DECIMAL(25,8)');
        $field->set('uitype', 7);
        $field->set('displaytype', 2);
        $field->set('typeofdata', 'N~O');

        foreach ($data as $key => $value) {
            $field->set($key, $value);
        }

        $field->save($this->getCashFlowBlock());

        $this->fields[$name] = $field;
    }

    /**
     * @param string $name
     * @return object
     */
    public function getCashFlowField($name)
    {
        return $this->fields[$name];
    }

    public function addCashFlowBlock()
    {
        $block = new Vtiger_Block();
        $block->label = self::BLOCK_LABEL;
        $block->save($this->getModuleInstance());

        $this->block = $block;
    }

    public function deleteCashFlowBlock()
    {
        $this->adb->pquery('DELETE FROM vtiger_blocks WHERE blocklabel=? AND tabid=?', array(self::BLOCK_LABEL, $this->getModuleInstance()->getId()));
    }

    public function getCashFlowBlock()
    {
        return $this->block;
    }

    public function updateRelatedLists($register = true)
    {
        $cashFlowInstance = $this->getCashFlow();
        $cashFlowLabel = self::RELATED_LIST_LABEL;
        $moduleInstance = $this->getModule();
        $moduleInstance->unsetRelatedList($cashFlowInstance, $cashFlowLabel);
        $moduleInstance->unsetRelatedList($cashFlowInstance, $cashFlowLabel, 'get_dependents_list');

        if ($register) {
            if ('Invoice' === $this->getModuleName()) {
                $moduleInstance->setRelatedList($cashFlowInstance, $cashFlowLabel, '');
            } else {
                $moduleInstance->setRelatedList($cashFlowInstance, $cashFlowLabel, '', 'get_dependents_list');
            }
        }
    }

    public function getCashFlow()
    {
        return Vtiger_Module::getInstance('Cashflow4You');
    }

    public function updateLinks($register = true)
    {
        $moduleInstance = $this->getModule();
        $moduleName = $this->getModuleName();
        $moduleInstance->deleteLink('DETAILVIEW', 'Add Payment');
        $moduleInstance->deleteLink('DETAILVIEW', 'Payments');
        $moduleInstance->deleteLink('LISTVIEWBASIC', 'Create Payment');
        $moduleInstance->deleteLink('LISTVIEWMASSACTION', 'Create Payment');

        if ($register) {
            $moduleInstance->addLink('DETAILVIEW', 'Add Payment', 'index.php?module=Cashflow4You&view=Edit&relationid=$RECORD$&sourceModule=$MODULE$&sourceRecord=$RECORD$&relationOperation=1', '');
            $moduleInstance->addLink('DETAILVIEW', 'Payments', 'javascript:Cashflow4You_Actions_Js.showPayments(this);');

            if ('Invoice' === $moduleName) {
                $moduleInstance->addLink('LISTVIEWBASIC', 'Create Payment', 'javascript:Cashflow4You_Actions_Js.CreatePayment("index.php?module=Cashflow4You&view=CreatePaymentActionAjax&mode=showCreatePaymentForm");');
                $moduleInstance->addLink('LISTVIEWMASSACTION', 'Create Payment', 'javascript:Cashflow4You_Actions_Js.CreatePayment("index.php?module=Cashflow4You&view=CreatePaymentActionAjax&mode=showCreatePaymentForm");');
            }
        }
    }

    public function isRelatedToModule()
    {
        return in_array($this->getModuleName(), ['Vendors', 'Contacts', 'Accounts']);
    }

    /**
     * @return array
     */
    public function getStatusFields()
    {
        $fields = $this->getModule()->getFieldsByType('picklist');

        foreach ($fields as $key => $field) {
            if (!$this->isAllowedPicklist($field)) {
                unset($fields[$key]);
            }
        }

        return $fields;
    }

    /**
     * @param Vtiger_Field_Model $field
     * @return bool
     */
    public function isAllowedPicklist($field)
    {
        return in_array($field->uitype, [15, 16]) && !in_array($field->name, $this->disabledPicklists);
    }

    public $disabledPicklists = [
        'hdnTaxType',
        'region_id',
    ];

    /**
     * @return array
     */
    public function getTotalFields()
    {
        $fields = $this->getModule()->getFieldsByType(array('double', 'currency'));

        foreach ($fields as $key => $field) {
            if (!in_array($field->name, ['amount', 'hdnGrandTotal'])) {
                unset($fields[$key]);
            }
        }

        return $fields;
    }

    /**
     * @return array
     */
    public function getRelatedToFields()
    {
        $fields = $this->getModule()->getFieldsByType('reference');

        /** @var Vtiger_Field_Model $field */
        foreach ($fields as $key => $field) {
            if (
                !in_array('Vendors', $field->getReferenceList()) &&
                !in_array('Accounts', $field->getReferenceList())
            ) {
                unset($fields[$key]);
            }
        }

        return $fields;
    }

    /**
     * @return false|Vtiger_Field
     */
    public function getRelatedToField()
    {
        return Vtiger_Field::getInstance($this->get('relatedto_field'), $this->getModule());
    }

    /**
     * @param Vtiger_Field_Model $field
     * @return string
     */
    public function getPicklistValue($field)
    {
        return htmlspecialchars(json_encode($field->getPicklistValues()), ENT_QUOTES, 'UTF-8');
    }

    /**
     * @return false|Vtiger_Field
     * @throws Exception
     */
    public function getNumberField()
    {
        $fieldId = $this->getNumberFieldId();

        return $fieldId ? Vtiger_Field::getInstance($fieldId, $this->getModule()) : false;
    }

    /**
     * @return string
     * @throws Exception
     */
    public function getNumberFieldColumn()
    {
        $field = $this->getNumberField();

        return $field ? $field->column : '';
    }

    /**
     * @return int
     * @throws Exception
     */
    public function getNumberFieldId()
    {
        $result = $this->adb->pquery('SELECT fieldid FROM vtiger_field WHERE tabid=? AND uitype=?', [$this->getModule()->getId(), 4]);

        return intval($this->adb->query_result($result, 0, 'fieldid'));
    }

    /**
     * @return bool
     */
    public function hasNumberField()
    {
        return $this->getModule()->hasSequenceNumberField();
    }

    /**
     * @return bool
     */
    public function hasTotalField()
    {
        $field = $this->getTotalField();

        return $field && columnExists($field->column, $field->table);
    }

    /**
     * @return false|Vtiger_Field
     */
    public function getTotalField()
    {
        return Vtiger_Field::getInstance($this->get('total_field'), $this->getModule());
    }

    /**
     * @return string
     */
    public function getTotalFieldColumn()
    {
        $field = $this->getTotalField();

        return $field ? $field->column : '';
    }

    public function getModuleTable()
    {
        return $this->getModule()->basetable;
    }

    public function getModuleTableId()
    {
        return $this->getModule()->basetableid;
    }

    public function getStatusColumn()
    {
        $field = $this->getStatusField();

        return $field ? $field->column : '';
    }

    /**
     * @return false|Vtiger_Field
     */
    public function getStatusField()
    {
        $fieldName = $this->get('status_field');

        if ($fieldName) {
            return Vtiger_Field::getInstance($fieldName, $this->getModule());
        }

        return false;
    }

    public function getPaymentsQuery()
    {
        $moduleTable = $this->getModuleTable();
        $moduleTableId = $this->getModuleTableId();

        if (self::SALES_ORDER === $this->getModuleName()) {
            $query = sprintf('SELECT vtiger_crmentity.*, its4you_cashflow4you.*, %s.*, vtiger_currency_info.currency_symbol, its4you_cashflow4you.paymentamount as partial_amount
                FROM its4you_cashflow4you 
                INNER JOIN vtiger_crmentityrel ON its4you_cashflow4you.cashflow4youid=vtiger_crmentityrel.crmid
                INNER JOIN %s ON %s.%s=vtiger_crmentityrel.relcrmid
                INNER JOIN vtiger_crmentity ON vtiger_crmentity.crmid=its4you_cashflow4you.cashflow4youid
                INNER JOIN vtiger_currency_info ON vtiger_currency_info.id = its4you_cashflow4you.currency_id 
                WHERE vtiger_crmentity.deleted=0
                AND vtiger_crmentityrel.relcrmid=?
                ORDER BY paymentdate, cashflow4youid',
                $moduleTable,
                $moduleTable,
                $moduleTable,
                $moduleTableId
            );
        } else {
            $query = sprintf('SELECT vtiger_crmentity.*, its4you_cashflow4you.*, %s.*, its4you_cashflow4you_associatedto.partial_amount, vtiger_currency_info.currency_symbol 
                    FROM its4you_cashflow4you 
                    INNER JOIN vtiger_crmentityrel ON its4you_cashflow4you.cashflow4youid=vtiger_crmentityrel.crmid
                    INNER JOIN %s ON %s.%s=vtiger_crmentityrel.relcrmid
                    INNER JOIN vtiger_crmentity ON vtiger_crmentity.crmid=its4you_cashflow4you.cashflow4youid
                    INNER JOIN its4you_cashflow4you_associatedto ON its4you_cashflow4you_associatedto.cashflow4youid=its4you_cashflow4you.cashflow4youid  
                    INNER JOIN vtiger_currency_info ON vtiger_currency_info.id = its4you_cashflow4you.currency_id 
                    WHERE vtiger_crmentity.deleted=0
                    AND vtiger_crmentityrel.relcrmid=?
                    AND its4you_cashflow4you_associatedto.cashflow4you_associated_id=vtiger_crmentityrel.relcrmid
                    ORDER BY paymentdate, cashflow4youid',
                $moduleTable,
                $moduleTable,
                $moduleTable,
                $moduleTableId
            );
        }

        return $query;
    }
}
<?php
/* * *******************************************************************************
 * The content of this file is subject to the Cashflow4You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

//require_once('modules/Cashflow4You/models/Utils.php');

class Cashflow4You_Record_Model extends Vtiger_Record_Model
{

    /**
     * Function returns collor
     */
    function getColor($name)
    {
        $collor = null;
        if ($name == "paymentamount") {
            $db = PearDatabase::getInstance();
            $id = $this->getId();

            $select_res = $db->pquery("SELECT cashflow4you_paytype FROM  its4you_cashflow4you WHERE cashflow4youid=?",
                array($id));
            $paytype = $db->query_result($select_res, 0, 'cashflow4you_paytype');
            $utils = new Cashflow4You_Utils_Model();

            if ($paytype == "Outgoing") {
                $collor = $utils->getColor("red");
            } else {
                $collor = $utils->getColor("green");
            }
        }
        return $collor;
    }

    /**
     * @param int $record
     * @param array $params
     */
    public static function updateRecord($record, $params)
    {
        $sql = sprintf('UPDATE its4you_cashflow4you SET %s=? WHERE cashflow4youid=?',
            implode('=?, ', array_keys($params))
        );
        $params[] = $record;

        PearDatabase::getInstance()->pquery($sql, $params);
    }

    /**
     * @throws Exception
     */
    public function getCurrencySymbol()
    {
        if ($this->isEmpty('currency_id')) {
            $this->retrieveCurrencyId();
        }

        $data = Vtiger_Functions::getCurrencySymbolandRate($this->get('currency_id'));

        return $data['symbol'];
    }

    /**
     * @throws Exception
     */
    public function retrieveCurrencyId()
    {
        $adb = PearDatabase::getInstance();
        $result = $adb->pquery('SELECT currency_id FROM its4you_cashflow4you WHERE cashflow4youid=?',
            [$this->getId()]
        );
        $this->set('currency_id', $adb->query_result($result, 0, 'currency_id'));
    }

    /**
     * @throws Exception
     */
    public function getPaymentAmountDisplayValue()
    {
        $currencyField = new CurrencyField((float)$this->get('paymentamount'));

        return CurrencyField::appendCurrencySymbol($currencyField->getDisplayValue(null, true), $this->getCurrencySymbol());
    }
}
<?php
/* *********************************************************************************
 * The content of this file is subject to the ITS4YouInstaller license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ******************************************************************************* */

$languageStrings = array(
	'MyExtension' => 'Installer', 
	'LBL_MODULE_NAME' => 'Installer', 
	'LBL_MANAGE_MODULES' => 'Manage Extensions', 
	'LBL_UPGRADE' => 'Upgrade', 
	'LBL_UNINSTALL' => 'Uninstall', 
	'LBL_LICENSE' => 'License', 
	'ITS4YouInstaller' => 'Installer', 
	'SINGLE_ITS4YouInstaller' => 'Installer', 
	'LBL_UNINSTALL_DESC' => 'Remove Module completely from your vTiger.', 
	'LBL_MODULE' => 'Module', 
	'LBL_LICENSE_SETTINGS_INFO' => 'Manage your Module License Key', 
	'LBL_LICENSE_DESC' => 'Manage all settings related to your license', 
	'LBL_URL' => 'Your vtiger url', 
	'LBL_LICENSE_ACTIVE' => 'Extension is active', 
	'LBL_LICENSE_INACTIVE' => 'Extension is not active', 
	'LBL_INSTALLER_NOT_ACTIVE' => 'Install or Activate ITS4YouInstaller module to manage your licenses.', 
	'LBL_INSTALLER_UPDATE' => 'Update ITS4YouInstaller module for access to ITS4YouInstaller', 
	'LBL_DOWNLOAD' => 'Download', 
	'LBL_DOWNLOAD_INSTALLER' => 'Download Installer', 
	'COPYRIGHT' => ':: IT-Solutions4You', 
	'LBL_SYSTEM_REQUIREMENTS' => 'System requirements', 
	'LBL_BLOCK_SYSTEM_INFORMATION' => 'System Information', 
	'LBL_EDIT_FIELDS' => 'Fields & Layout', 
	'LBL_EDIT_WORKFLOWS' => 'Workflows', 
	'LBL_MODULE_SEQUENCE_NUMBERING' => 'Numbering', 
	'LBL_VERSION' => 'Version', 
	'LBL_INTEGRATION' => 'Integration', 
	'LBL_MODULE_REQUIREMENTS' => 'Module Requirements', 
	'LBL_REQUIREMENTS' => 'Requirements', 
	'LBL_CLEAR_CACHE' => 'Clear Cache', 
	'LBL_SCAN_SUB_FOLDERS' => 'Scan sub folders and files', 
	'LBL_LICENSE_MANAGE' => 'Manage licenses', 
	'LBL_SELECT_SOURCE_MODULE' => 'Select Source module', 
	'LBL_MODULE_NOT_ACTIVE_OR_DELETED' => 'Source Module is not active or deleted', 
	'LBL_FINISH_MARKETING_BEFORE_UPDATE' => 'Required to finish or stop all EmailMarketing before update', 
	'LBL_LICENSE_USED_BY_OTHER_USERS' => 'Počet zakúpených licencií pre používateľov bol dosiahnutý. Bol dosiahnutý limit používateľských licencií.', 
);

$jsLanguageStrings = array(
	'JS_UNINSTALL_CONFIRM' => 'Are you sure to completely remove module from your vTiger?', 
); 


Vtiger_Index_Js('ITS4YouSMTP_Detail_Js', {}, {
    registerEvents: function () {
        this._super();
    },
});
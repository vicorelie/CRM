Vtiger_Index_Js('ITS4YouSMTP_List_Js', {}, {
    registerEvents: function() {
        this.registerAppTriggerEvent();
    },
});